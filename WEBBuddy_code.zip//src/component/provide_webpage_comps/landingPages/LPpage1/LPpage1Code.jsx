import SyntaxHighlighter from "react-syntax-highlighter";
import { atomOneDark } from "react-syntax-highlighter/dist/esm/styles/hljs";

export default LPpage1Code = () => {
  const codeString = `
  <!-- HTML Code -->

  <header>
  <nav class="navbar">
    <div class="logo">Design<span>Studio</span></div>
    <ul class="nav-links">
      <li><a href="#about">About</a></li>
      <li><a href="#projects">Projects</a></li>
      <li><a href="#contact">Contact</a></li>
    </ul>
    <button class="cta-button">Hire Me</button>
  </nav>
</header>

<section class="hero">
  <div class="hero-text">
    <h1>Design Your Vision<br><span>With Creativity</span></h1>
    <p>Creating bold, dynamic, and innovative designs that captivate and inspire.</p>
    <button class="cta-button">Explore Portfolio</button>
  </div>
  <div class="hero-image">
    <img src="designer-hero.jpg" alt="Designer at Work">
  </div>
</section>

<section id="about" class="about">
  <h2>About Me</h2>
  <p>I’m a creative designer with expertise in UI/UX, branding, and visual storytelling. My goal is to turn ideas into experiences.</p>
</section>

<section id="projects" class="projects">
  <h2>My Projects</h2>
  <div class="project-gallery">
    <div class="project-item">
      <img src="project1.jpg" alt="Project 1">
      <h3>Branding Identity</h3>
    </div>
    <div class="project-item">
      <img src="project2.jpg" alt="Project 2">
      <h3>UI/UX Design</h3>
    </div>
    <div class="project-item">
      <img src="project3.jpg" alt="Project 3">
      <h3>Creative Art</h3>
    </div>
  </div>
</section>

<section id="contact" class="contact">
  <h2>Contact Me</h2>
  <p>Let’s bring your ideas to life. Reach out for collaborations or inquiries.</p>
  <form action="submit-form" method="post" class="contact-form">
    <input type="text" name="name" placeholder="Your Name" required>
    <input type="email" name="email" placeholder="Your Email" required>
    <textarea name="message" rows="5" placeholder="Your Message" required></textarea>
    <button type="submit" class="cta-button">Send Message</button>
  </form>
</section>

<footer>
  <p>&copy; 2024 DesignStudio. All Rights Reserved.</p>
</footer>

<!-- CSS Code -->

  /* General Reset */
  * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
  }
  
  body {
    font-family: 'Poppins', sans-serif;
    color: #333;
    line-height: 1.6;
    background: #f5f5f5;
  }
  
  /* Navbar */
  .navbar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 1rem 2rem;
    background: linear-gradient(90deg, #ff7eb3, #ff758c);
    color: #fff;
  }
  
  .logo {
    font-size: 1.5rem;
    font-weight: bold;
  }
  
  .logo span {
    color: #ffe084;
  }
  
  .nav-links {
    display: flex;
    list-style: none;
  }
  
  .nav-links li {
    margin: 0 1rem;
  }
  
  .nav-links a {
    text-decoration: none;
    color: #fff;
    font-weight: 600;
  }
  
  .cta-button {
    padding: 0.6rem 1.6rem;
    background: #ffe084;
    color: #333;
    border: none;
    border-radius: 20px;
    cursor: pointer;
    transition: background 0.3s;
  }
  
  .cta-button:hover {
    background: #ffc556;
  }
  
  /* Hero Section */
  .hero {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 4rem 2rem;
    background: linear-gradient(135deg, #ff758c, #ffe084);
  }
  
  .hero-text h1 {
    font-size: 3rem;
    color: #fff;
    margin-bottom: 1rem;
  }
  
  .hero-text h1 span {
    color: #333;
  }
  
  .hero-text p {
    font-size: 1.2rem;
    color: #fff;
    margin-bottom: 1.5rem;
  }
  
  .hero-image img {
    width: 100%;
    max-width: 500px;
    border-radius: 10px;
  }
  
  /* About Section */
  .about {
    text-align: center;
    padding: 3rem 2rem;
    background: #ffe084;
  }
  
  .about h2 {
    font-size: 2rem;
    color: #333;
  }
  
  .about p {
    font-size: 1rem;
    color: #555;
    margin-top: 1rem;
  }
  
  /* Projects Section */
  .projects {
    padding: 3rem 2rem;
    background: #ff758c;
    color: #fff;
  }
  
  .projects h2 {
    text-align: center;
    font-size: 2rem;
    margin-bottom: 2rem;
  }
  
  .project-gallery {
    display: flex;
    gap: 1rem;
    justify-content: center;
    flex-wrap: wrap;
  }
  
  .project-item {
    width: 300px;
    background: #fff;
    border-radius: 10px;
    padding: 1rem;
    text-align: center;
    transition: transform 0.3s;
  }
  
  .project-item:hover {
    transform: scale(1.05);
  }
  
  .project-item img {
    width: 100%;
    border-radius: 10px;
    margin-bottom: 1rem;
  }
  
  /* Contact Section */
  .contact {
    padding: 3rem 2rem;
    text-align: center;
    background: #ffe084;
  }
  
  .contact-form {
    margin-top: 1rem;
    display: flex;
    flex-direction: column;
    gap: 1rem;
    width: 300px;
    margin: 0 auto;
  }
  
  .contact-form input,
  .contact-form textarea {
    padding: 0.8rem;
    border-radius: 10px;
    border: 1px solid #ccc;
    font-size: 1rem;
  }
  
  .contact-form button {
    background: #ff758c;
    color: #fff;
    border: none;
    border-radius: 20px;
    padding: 0.8rem;
    cursor: pointer;
    transition: background 0.3s;
  }
  
  .contact-form button:hover {
    background: #ff4a6e;
  }
  
  /* Footer */
  footer {
    text-align: center;
    padding: 1rem;
    background: #333;
    color: #fff;
  }
  
      `;
  return (
    <SyntaxHighlighter language="HTML" style={atomOneDark}>
      {codeString}
    </SyntaxHighlighter>
  );
};
