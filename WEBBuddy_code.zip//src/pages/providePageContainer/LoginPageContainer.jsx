import { Link } from "react-router-dom";

import Page1Code from "../../component/provide_webpage_comps/loginPages/page1/Page1Code";
import Page2Code from "../../component/provide_webpage_comps/loginPages/page2/Page2Code";

export default function LoginPageContainer() {
  return (
    <div className="login-page-con-center">
      <div className="page-center">
        <Link to="/loginpage1">
          <div className="page-container">
            <img
              src="http://127.0.0.1:5500/media/loginpage-1.png"
              alt="login-page-img-1"
              height="520"
              width="900"
            />
          </div>
        </Link>
        <div className="code-container-2">
          <Page1Code />
        </div>
      </div>
      <div className="page-center">
        <Link to="/loginpage2">
          <div className="page-container">
            <img
              src="http://127.0.0.1:5500/media/loginpage-2.png"
              alt="login-page-img-2"
              height="520"
              width="900"
            />
          </div>
        </Link>
        <div className="code-container-2">
          <Page2Code />
        </div>
      </div>
    </div>
  );
}
