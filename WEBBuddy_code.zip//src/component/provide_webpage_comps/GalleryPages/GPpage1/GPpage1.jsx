import "./GPpage1.css";

export default function () {
  return (
    <div>
      <header className="gallery-header">
        <h1>Project Gallery</h1>
        <p>Explore the collection of my creative projects.</p>
      </header>

      <section class="gallery">
        <div class="gallery-item">
          <img
            src="https://img.freepik.com/free-vector/new-normal-museums-concept_23-2148587884.jpg?ga=GA1.1.259908405.1723487220&semt=ais_hybrid"
            alt="Project 1"
          />
          <div class="info">
            <h2>Project 1</h2>
            <p>Description of the first project.</p>
          </div>
        </div>
        <div class="gallery-item">
          <img
            src="https://img.freepik.com/free-vector/new-normal-museums_23-2148575036.jpg?ga=GA1.1.259908405.1723487220&semt=ais_hybrid"
            alt="Project 2"
          />
          <div class="info">
            <h2>Project 2</h2>
            <p>Description of the second project.</p>
          </div>
        </div>
        <div class="gallery-item">
          <img
            src="https://img.freepik.com/free-vector/new-normal-museums-concept_23-2148587008.jpg?ga=GA1.1.259908405.1723487220&semt=ais_hybrid"
            alt="Project 3"
          />
          <div class="info">
            <h2>Project 3</h2>
            <p>Description of the third project.</p>
          </div>
        </div>
        <div class="gallery-item">
          <img
            src="https://img.freepik.com/free-vector/new-normal-museums-concept_23-2148587884.jpg?ga=GA1.1.259908405.1723487220&semt=ais_hybrid"
            alt="Project 1"
          />
          <div class="info">
            <h2>Project 1</h2>
            <p>Description of the first project.</p>
          </div>
        </div>
        <div class="gallery-item">
          <img
            src="https://img.freepik.com/free-vector/new-normal-museums-concept_23-2148587884.jpg?ga=GA1.1.259908405.1723487220&semt=ais_hybrid"
            alt="Project 1"
          />
          <div class="info">
            <h2>Project 1</h2>
            <p>Description of the first project.</p>
          </div>
        </div>
        <div class="gallery-item">
          <img
            src="https://img.freepik.com/free-vector/new-normal-museums-concept_23-2148587884.jpg?ga=GA1.1.259908405.1723487220&semt=ais_hybrid"
            alt="Project 1"
          />
          <div class="info">
            <h2>Project 1</h2>
            <p>Description of the first project.</p>
          </div>
        </div>
        <div class="gallery-item">
          <img
            src="https://img.freepik.com/free-vector/new-normal-museums-concept_23-2148587008.jpg?ga=GA1.1.259908405.1723487220&semt=ais_hybrid"
            alt="Project 3"
          />
          <div class="info">
            <h2>Project 3</h2>
            <p>Description of the third project.</p>
          </div>
        </div>
        <div class="gallery-item">
          <img
            src="https://img.freepik.com/free-vector/new-normal-museums-concept_23-2148587008.jpg?ga=GA1.1.259908405.1723487220&semt=ais_hybrid"
            alt="Project 3"
          />
          <div class="info">
            <h2>Project 3</h2>
            <p>Description of the third project.</p>
          </div>
        </div>
      </section>

      <footer>
        <p>&copy; 2024 My Projects Gallery</p>
      </footer>
    </div>
  );
}
