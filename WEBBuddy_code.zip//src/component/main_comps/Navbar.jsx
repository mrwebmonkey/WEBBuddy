import { NavLink } from "react-router-dom";

export default function Navbar() {
  return (
    <div className="navbar">
      <h2 className="custom-font webbuddy-logo">WB.</h2>
      <NavLink to="/about" className="navlink ">
        <p className="custom-font ">About</p>
      </NavLink>
      <p className="custom-font">Submit</p>
      <input
        className="custom-font"
        type="search"
        placeholder="search for component"
      />
      <button className="custom-font" id="login_btn">
        Login
      </button>
      <button className="custom-font" id="signup-btn">
        SignUp
      </button>
    </div>
  );
}
