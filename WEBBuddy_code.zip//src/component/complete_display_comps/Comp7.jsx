import React from "react";

import Loader from "../provide_comps/terminalLoder/Loader";
import LoaderCode from "../provide_comps/terminalLoder/LoaderCode";

export default function Comp2() {
  return (
    <div>
      <div className="info-of-component">
        <p>
          Login forms are an essential part of web application, providing a
          secure way for users to access personalized content or functionality.
        </p>
      </div>
      <div className="preview-box">
        <div className="preview-box-head">
          <p>Preview</p>
        </div>
        <div className="preview">
          <Loader />
        </div>
      </div>
      <div className="code-box">
        <div className="code-container-head">
          <p>Code</p>
        </div>
        <div className="code">
          <LoaderCode />
        </div>
      </div>
    </div>
  );
}
