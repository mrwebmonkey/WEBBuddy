import SyntaxHighlighter from "react-syntax-highlighter";
import { atomOneDark } from "react-syntax-highlighter/dist/esm/styles/hljs";

export default Component = () => {
  const codeString = `
<!-- HTML Code -->

<!-- Avatar with image -->
<div class="avatar">
  <img src="https://img.freepik.com/premium-vector/cartoon-illustration-swat-special-agent_272293-4608.jpg?ga=GA1.1.259908405.1723487220&semt=ais_hybrid" alt="User Avatar">
</div>

<!-- Avatar with initials fallback -->
<div class="avatar">
  JD
</div>

<!-- Small avatar -->
<div class="avatar small">
  <img src="https://img.freepik.com/free-vector/young-man-black-shirt_1308-173618.jpg?ga=GA1.1.259908405.1723487220&semt=ais_hybrid" alt="User Avatar">
</div>

<!-- Large avatar -->
<div class="avatar large">
  EM
</div>

<!-- CSS Code -->

body {
  font-family: Arial, sans-serif;
  margin: 20px;
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  background-color: #f9f9f9;
}

.avatar {
  display: inline-flex;
  justify-content: center;
  align-items: center;
  width: 100px;
  height: 100px;
  border-radius: 50%;
  overflow: hidden;
  background-color: #4CAF50;
  color: #ffffff;
  font-size: 36px;
  font-weight: bold;
  text-transform: uppercase;
  position: relative;
}
.avatar img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  display: block;
}
/* Optional size variants */
.avatar.small {
  width: 50px;
  height: 50px;
  font-size: 18px;
}
.avatar.large {
  width: 150px;
  height: 150px;
  font-size: 48px;
}

      `;
  return (
    <div className="code-container">
      <SyntaxHighlighter language="HTML" style={atomOneDark}>
        {codeString}
      </SyntaxHighlighter>
    </div>
  );
};
