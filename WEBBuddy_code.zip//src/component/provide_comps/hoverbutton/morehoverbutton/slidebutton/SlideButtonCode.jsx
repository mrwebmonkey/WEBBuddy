import SyntaxHighlighter from "react-syntax-highlighter";
import { atomOneDark } from "react-syntax-highlighter/dist/esm/styles/hljs";

export default Component = () => {
  const codeString = `
  <!-- HTML Code -->

  <button class="button-slide">Hover Me</button>
  
  <!-- CSS Code -->

  .button-slide {
    color: #fff;
    background: transparent;
    border: 2px solid #00d9ff;
    padding: 15px 30px;
    font-size: 18px;
    cursor: pointer;
    text-transform: uppercase;
    border-radius: 30px;
    position: relative;
    overflow: hidden;
    transition: all 0.4s ease;
  }
  .button-slide:hover {
    background: #00d9ff;
    color: #282c34;
    box-shadow: 0 4px 15px rgba(0, 217, 255, 0.5);
  }
  .button-slide::before {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, #00d9ff, #ff6a00);
    transform: translateX(-100%);
    z-index: -1;
    transition: transform 0.4s ease;
  }
  .button-slide:hover::before {
    transform: translateX(0);
  }
  
      `;
  return (
    <div className="code-container">
      <SyntaxHighlighter language="HTML" style={atomOneDark}>
        {codeString}
      </SyntaxHighlighter>
    </div>
  );
};
