import React from "react";
import { NavLink } from "react-router-dom";

export default function Navigationtab() {
  return (
    <div className="navigate">
      <NavLink to="/">
        <button id="all" className=" custom-font  nav-btn-hover">
          ALL
        </button>
      </NavLink>

      <NavLink to="/components">
        <button className=" custom-font  more-width nav-btn-hover">
          Components
        </button>
      </NavLink>

      <NavLink to="/website">
        <button className=" custom-font  more-width nav-btn-hover">
          Webpages
        </button>
      </NavLink>

      <button className=" custom-font  more-width nav-btn-hover">
        Portfolio
      </button>
    </div>
  );
}
