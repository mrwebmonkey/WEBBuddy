import React from "react";

import "../../pages/pages.css";
import Button from "../provide_comps/buttons/Button";
import ButtonCode from "../provide_comps/buttons/ButtonCode";

export default function Comp1() {
  return (
    <div>
      <div className="info-of-component">
        <p>
          Buttons are essential UI elements in web design that facilitate user
          interaction with a website or web application.
        </p>
      </div>
      <div className="preview-box">
        <div className="preview-box-head">
          <p>Preview</p>
        </div>
        <div className="preview">
          <Button />
        </div>
      </div>
      <div className="code-box custom-font">
        <div className="code-container-head">
          <p>Code</p>
        </div>
        <div className="code">
          <ButtonCode />
        </div>
      </div>
    </div>
  );
}
