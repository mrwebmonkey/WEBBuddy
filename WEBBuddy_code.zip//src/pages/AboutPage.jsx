export default function () {
  return (
    <div class="main-about-container">
      <div className="main-header">
        <h1>
          About <span class="highlight">WB.</span>
        </h1>
      </div>
      <section class="vision">
        <h2>The Vision</h2>
        <p>
          WEBBuddy was born out of a desire to redefine
          <strong>UI components and Web pages</strong>. By blending cutting-edge
          technology with thoughtful design, this project aims to
          <em>Provide UI component and Web pages for users</em>.
        </p>
      </section>
      <section class="features">
        <h2>Key Features</h2>
        <ul>
          <li>
            <strong>Modern Design:</strong> A sleek interface tailored for
            intuitive navigation.
          </li>
          <li>
            <strong>Innovation at Core:</strong> Leveraging the latest tools and
            techniques to push boundaries.
          </li>
        </ul>
      </section>
      <section class="creator-note">
        <h2>The Creator's Note</h2>
        <p>
          Hi, I’m <strong>Saurabh</strong>! As a<strong>developer</strong>.
          WEBBuddy is my way of exploring, experimenting, and sharing ideas with
          the world. I hope it sparks as much joy in you as it has in me while
          bringing it to life.
        </p>
      </section>
      <section class="tech-stack">
        <h2>Behind the Code</h2>
        <ul>
          <li>
            <strong>Built using:</strong> React and React Librarys
          </li>
          <li>
            <strong>Designed to:</strong> Provide UI component and Web pages
          </li>
        </ul>
      </section>
      <footer>
        <p>
          Let’s Connect: <a href="#">8400966145</a>
        </p>
      </footer>
    </div>
  );
}
