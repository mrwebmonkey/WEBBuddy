import { Link } from "react-router-dom";
import LPpage1Code from "../../component/provide_webpage_comps/landingPages/LPpage1/LPpage1Code";
import LPpage2Code from "../../component/provide_webpage_comps/landingPages/Lppage2/LPpage2Code";

export default function LandingPageContainer() {
  return (
    <div className="login-page-con-center">
      <div className="page-center">
        <Link to="/landingpage1">
          <div className="page-container">
            <img
              src="http://127.0.0.1:5500/media/landingpage-1.png"
              alt="login-page"
              height="520"
              width="900"
            />
          </div>
        </Link>
        <div className="code-container-2">
          <LPpage1Code />
        </div>
      </div>

      <div className="page-center">
        <Link to="/landingpage2">
          <div className="page-container">
            <img
              src="http://127.0.0.1:5500/media/landingpage-2.png"
              alt="login-page"
              height="520"
              width="900"
            />
          </div>
        </Link>
        <div className="code-container-2">
          <LPpage2Code />
        </div>
      </div>
    </div>
  );
}
