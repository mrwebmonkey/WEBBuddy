import React from "react";
import "../../pages/pages.css";

export default function Comp0() {
  return (
    <div>
      <div className="info-of-component">
        <p style={{ marginLeft: "25px" }}>
          <h1>How to Use Our Website Components</h1>
          <br />
          Welcome to our website! We’re excited to help you enhance your
          projects with our ready-to-use website components. Follow the simple
          steps below to get started:
          <br />
          <br />
          <ul>
            <li>
              <h3>Browse Our Components:</h3> Explore our collection of website
              components displayed on the homepage. Each component comes with a
              preview that showcases how it looks and functions.
            </li>
            <br />
            <li>
              <h3>Select a Component:</h3> Once you find a component that fits
              your needs.
            </li>
            <br />
            <li>
              <h3>View the Preview:</h3> On each component's detail page, you
              will see a preview section. This allows you to see exactly how the
              component appears in a real-world context.
            </li>
            <br />
            <li>
              <h3>Copy the Code:</h3>Below the preview, you will find a code box
              containing the HTML and CSS code for that specific component.
            </li>
            <br />
            <li>
              <h3>Paste the Code into Your Project:</h3> Open your own HTML and
              CSS files in your code editor. Simply paste the copied code where
              you’d like the component to appear in your project.
            </li>
            <br />
            <li>
              <h3>Customize (Optional):</h3> Feel free to customize the code as
              needed! You can adjust styles, colors, and content to better fit
              your project’s design and functionality.
            </li>
            <br />
            <li>
              <h3>Save & Test:</h3> After pasting and making any changes, save
              your files and open your project in a web browser to see your new
              component in action.
            </li>
            <br />
            <li>
              <h3>Tips for Success:</h3>
              <h4>- Check Compatibility:</h4> Ensure that the component you are
              using is compatible with the rest of your website's code and
              design.
              <h4>- Explore Documentation:</h4> If available, check any
              additional documentation for specific usage instructions or best
              practices related to the component.
            </li>
            <br />
            We hope you enjoy using our website components! If you have any
            questions or need further assistance, feel free to reach out to our
            support team.
            <br />
            <br />
            <h2>Happy coding!</h2>
          </ul>
        </p>
      </div>
    </div>
  );
}
