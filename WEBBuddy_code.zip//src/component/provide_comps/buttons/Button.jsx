import "./button.css";

export default function Button() {
  return (
    <div>
      <div class="button-container">
        <button class="btn primary">Primary Button</button>
        <button class="btn secondary">Secondary Button</button>
        <button class="btn danger">Danger Button</button>
      </div>
    </div>
  );
}
