import SyntaxHighlighter from "react-syntax-highlighter";
import { atomOneDark } from "react-syntax-highlighter/dist/esm/styles/hljs";

export default Component = () => {
  const codeString = `
<!-- HTML Code -->

<div style="width: 80%; background-color: #e0e0e0; border-radius: 5px; overflow: hidden;">
  <div style="width: 70%; background-color: #000; height: 20px; transition: width 0.3s;"></div>
</div>

      `;
  return (
    <div className="code-container">
      <SyntaxHighlighter language="HTML" style={atomOneDark}>
        {codeString}
      </SyntaxHighlighter>
    </div>
  );
};
