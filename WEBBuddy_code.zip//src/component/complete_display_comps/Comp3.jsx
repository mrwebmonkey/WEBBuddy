import React from "react";

import Card from "../provide_comps/cards/Card";
import CardCode from "../provide_comps/cards/CardCode";
import HoverCard from "../provide_comps/cards/HoverCard";
import HoverCardCode from "../provide_comps/cards/HoverCardCode";

export default function Comp2() {
  return (
    <div>
      <div className="info-of-component">
        <p>
          Cards are versatile UI components commonly used in websites and web
          applications.
        </p>
      </div>
      <div className="preview-box">
        <div className="preview-box-head">
          <p>Preview</p>
        </div>
        <div className="preview">
          <HoverCard />
        </div>
      </div>
      <div className="code-box">
        <div className="code-container-head">
          <p>Code</p>
        </div>
        <div className="code">
          <HoverCardCode />
        </div>
      </div>

      <div className="preview-box">
        <div className="preview-box-head">
          <p>Preview</p>
        </div>
        <div className="preview">
          <Card />
        </div>
      </div>
      <div className="code-box">
        <div className="code-container-head">
          <p>Code</p>
        </div>
        <div className="code">
          <CardCode />
        </div>
      </div>
    </div>
  );
}
