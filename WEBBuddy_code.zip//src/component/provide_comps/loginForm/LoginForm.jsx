import React from "react";
import "../loginForm/LoginForm.css";

export default function LoginForm() {
  return (
    <div>
      <div class="login-container">
        <form class="login-form">
          <h2>Login</h2>
          <div class="input-container">
            <input type="text" id="username" required />
            <label for="username">Username</label>
          </div>
          <div class="input-container">
            <input type="password" id="password" required />
            <label for="password">Password</label>
          </div>
          <button type="submit">Login</button>
        </form>
      </div>
    </div>
  );
}
