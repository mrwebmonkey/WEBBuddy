import { Link } from "react-router-dom";
import GPpage1Code from "../../component/provide_webpage_comps/GalleryPages/GPpage1/GPpage1Code";

export default function GalleryPageContainer() {
  return (
    <div className="login-page-con-center">
      <div className="page-center">
        <Link to="/Gallerypage1">
          <div className="page-container">
            <img
              src="http://127.0.0.1:5500/media/gallerypage-1.png"
              alt="login-page"
              height="520"
              width="900"
            />
          </div>
        </Link>
        <div className="code-container-2">
          <GPpage1Code />
        </div>
      </div>
    </div>
  );
}
