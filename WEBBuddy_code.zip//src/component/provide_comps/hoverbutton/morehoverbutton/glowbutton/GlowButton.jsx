import "./GlowButton.css";

export default function () {
  return <button class="button-glow">Hover Me</button>;
}
