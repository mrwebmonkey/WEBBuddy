import "./Page2.css";

export default function Page2() {
  return (
    <div className="website2">
      <div className="left-container">
        <img
          src="https://img.freepik.com/free-vector/login-concept-illustration_114360-739.jpg?ga=GA1.1.259908405.1723487220&semt=ais_hybrid"
          alt=""
          height="450"
        />
      </div>
      <div className="right-container">
        <h2>Create a New Account</h2>
        <div className="input-box">
          <label>Full Name</label>
          <input type="text" />
          <label>Email Address</label>
          <input type="email" />
          <label>Passward</label>
          <input type="password" />
          <label>Confirm Passward</label>
          <input type="password" />
        </div>
        <br />
        <br />
        <button>Sign Up</button>
        <p>Already have an account ? Log In</p>
      </div>
    </div>
  );
}
