import React from "react";

import MusicMenu from "../provide_comps/musicmenu/MusicMenu";
import MusicMenuCode from "../provide_comps/musicmenu/MusicMenuCode";

export default function Comp2() {
  return (
    <div>
      <div className="info-of-component">
        <p>
          Description: Music menus manage playback and control for music
          players. Usage: Media applications and websites. Features: Play/pause,
          next/previous track, volume control, shuffle/repeat, and track
          listing.
        </p>
      </div>
      <div className="preview-box">
        <div className="preview-box-head">
          <p>Preview</p>
        </div>
        <div className="preview">
          <MusicMenu />
        </div>
      </div>
      <div className="code-box">
        <div className="code-container-head">
          <p>Code</p>
        </div>
        <div className="code">
          <MusicMenuCode />
        </div>
      </div>
    </div>
  );
}
