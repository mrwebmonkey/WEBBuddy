import React from "react";

import Avatar from "../provide_comps/avatar/Avatar";
import AvatarCode from "../provide_comps/avatar/AvatarCode";

export default function Comp2() {
  return (
    <div>
      <div className="info-of-component">
        <p>
          An avatar is a visual representation of a person, user, or character.
          It is widely used in digital interfaces, social platforms, and
          applications to help users identify themselves and others. Avatars can
          take various forms, such as images, icons, or even custom
          illustrations.
        </p>
      </div>
      <div className="preview-box">
        <div className="preview-box-head">
          <p>Preview</p>
        </div>
        <div className="preview">
          <Avatar />
        </div>
      </div>
      <div className="code-box">
        <div className="code-container-head">
          <p>Code</p>
        </div>
        <div className="code">
          <AvatarCode />
        </div>
      </div>
    </div>
  );
}
