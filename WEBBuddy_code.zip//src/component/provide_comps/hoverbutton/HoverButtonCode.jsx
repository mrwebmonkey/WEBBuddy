import SyntaxHighlighter from "react-syntax-highlighter";
import { atomOneDark } from "react-syntax-highlighter/dist/esm/styles/hljs";

export default Component = () => {
  const codeString = `
  <!-- HTML Code -->

  <div class="container">
        <button class="hover-button">Hover Me!</button>
  </div>
  
  <!-- CSS Code -->

  .container {
    text-align: center;
  }
  
  .hover-button {
    padding: 15px 30px;
    font-size: 18px;
    color: white;
    background-color: #007bff;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    transition: transform 0.3s ease, background-color 0.3s ease;
  }
  
  .hover-button:hover {
    transform: scale(1.1);
    background-color: #0056b3;
  }
      `;
  return (
    <div className="code-container">
      <SyntaxHighlighter language="HTML" style={atomOneDark}>
        {codeString}
      </SyntaxHighlighter>
    </div>
  );
};
