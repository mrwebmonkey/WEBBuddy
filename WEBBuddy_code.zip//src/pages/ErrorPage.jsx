import { Link } from "react-router-dom";
export default function ErrorPage() {
  return (
    <div className="error-container custom-font-2">
      <div className="go-back">
        <Link to="/">
          <h3>Back to Home </h3>
        </Link>
      </div>
      <h1>404</h1>
    </div>
  );
}
