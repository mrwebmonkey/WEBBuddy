import React from "react";

import HoverButton from "../provide_comps/hoverbutton/HoverButton";
import HoverButtonCode from "../provide_comps/hoverbutton/HoverButtonCode";
import GlowButton from "../provide_comps/hoverbutton/morehoverbutton/glowbutton/GlowButton";
import GlowButtonCode from "../provide_comps/hoverbutton/morehoverbutton/glowbutton/GlowButtonCode";
import SlideButton from "../provide_comps/hoverbutton/morehoverbutton/slidebutton/SlideButton";
import SlideButtonCode from "../provide_comps/hoverbutton/morehoverbutton/slidebutton/SlideButtonCode";
import RippleButton from "../provide_comps/hoverbutton/morehoverbutton/ripplebutton/RippleButton";
import RippleButtonCode from "../provide_comps/hoverbutton/morehoverbutton/ripplebutton/RippleButtonCode";

export default function Comp2() {
  return (
    <div>
      <div className="info-of-component">
        <p>
          Buttons are essential UI elements in web design that facilitate user
          interaction with a website or web application.
        </p>
      </div>
      <div className="preview-box">
        <div className="preview-box-head">
          <p>Preview</p>
        </div>
        <div className="preview">
          <HoverButton />
        </div>
      </div>
      <div className="code-box">
        <div className="code-container-head">
          <p>Code</p>
        </div>
        <div className="code">
          <HoverButtonCode />
        </div>
      </div>

      {/* glow button */}

      <div className="preview-box">
        <div className="preview-box-head">
          <p>Preview</p>
        </div>
        <div className="preview">
          <GlowButton />
        </div>
      </div>
      <div className="code-box">
        <div className="code-container-head">
          <p>Code</p>
        </div>
        <div className="code">
          <GlowButtonCode />
        </div>
      </div>

      {/* slide button */}

      <div className="preview-box">
        <div className="preview-box-head">
          <p>Preview</p>
        </div>
        <div className="preview">
          <SlideButton />
        </div>
      </div>
      <div className="code-box">
        <div className="code-container-head">
          <p>Code</p>
        </div>
        <div className="code">
          <SlideButtonCode />
        </div>
      </div>

      {/* ripple effect button */}

      <div className="preview-box">
        <div className="preview-box-head">
          <p>Preview</p>
        </div>
        <div className="preview">
          <RippleButton />
        </div>
      </div>
      <div className="code-box">
        <div className="code-container-head">
          <p>Code</p>
        </div>
        <div className="code">
          <RippleButtonCode />
        </div>
      </div>
    </div>
  );
}
