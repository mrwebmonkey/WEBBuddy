export default function OptionsComp({ items, isSelect, setIsSelect }) {
  return (
    <div>
      <ul className="custom-font">
        {items.map((text, index) => {
          return (
            <li
              className={isSelect == index ? "hover" : "li"}
              onClick={() => {
                setIsSelect(index);
              }}
            >
              {text}
            </li>
          );
        })}
      </ul>
    </div>
  );
}
