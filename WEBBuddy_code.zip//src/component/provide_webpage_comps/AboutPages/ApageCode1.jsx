import SyntaxHighlighter from "react-syntax-highlighter";
import { atomOneDark } from "react-syntax-highlighter/dist/esm/styles/hljs";

export default Apage1Code = () => {
  const codeString = `
<!-- HTML Code -->

<div class="about-container">
      <header>
        <h1>
          About <span class="highlight">[Project Name]</span>
        </h1>
      </header>
      <section class="vision">
        <h2>The Vision</h2>
        <p>
          [Project Name] was born out of a desire to redefine{" "}
          <strong>[specific domain or goal]</strong>. By blending cutting-edge
          technology with thoughtful design, this project aims to{" "}
          <em>[mission statement]</em>.
        </p>
      </section>
      <section class="features">
        <h2>Key Features</h2>
        <ul>
          <li>
            <strong>Modern Design:</strong> A sleek interface tailored for
            intuitive navigation.
          </li>
          <li>
            <strong>Purpose-Driven:</strong> Focused on solving real-world
            problems with precision.
          </li>
          <li>
            <strong>Innovation at Core:</strong> Leveraging the latest tools and
            techniques to push boundaries.
          </li>
        </ul>
      </section>
      <section class="creator-note">
        <h2>The Creator's Note</h2>
        <p>
          Hi, I’m <strong>[Your Name]</strong>! As a{" "}
          <strong>[Your Role]</strong>, I believe in the power of{" "}
          <strong>[values]</strong>. [Project Name] is my way of exploring,
          experimenting, and sharing ideas with the world. I hope it sparks as
          much joy in you as it has in me while bringing it to life.
        </p>
      </section>
      <section class="tech-stack">
        <h2>Behind the Code</h2>
        <ul>
          <li>
            <strong>Built using:</strong> [List main technologies/frameworks]
          </li>
          <li>
            <strong>Designed to:</strong> [Highlight key goals]
          </li>
          <li>
            <strong>Fueled by:</strong> [Inspirations]
          </li>
        </ul>
      </section>
      <footer>
        <p>
          Let’s Connect: <a href="#">[Social Media Links or Contact]</a>
        </p>
      </footer>
</div>

<!-- CSS Code -->

.about-container {
  max-width: 800px;
  margin: 20px auto;
  padding: 20px;
  background: #fff;
  border-radius: 10px;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
}

header h1 {
  text-align: center;
  font-size: 2.5em;
  margin-bottom: 10px;
}

.highlight {
  color: #007acc;
}

section {
  margin-bottom: 30px;
}

h2 {
  color: #444;
  margin-bottom: 10px;
  border-bottom: 2px solid #007acc;
  display: inline-block;
  padding-bottom: 5px;
}

p,
li {
  line-height: 1.6;
}

ul {
  padding-left: 20px;
  list-style: disc;
}

footer {
  text-align: center;
  margin-top: 20px;
  font-size: 0.9em;
  color: #666;
}

footer a {
  color: #007acc;
  text-decoration: none;
}

footer a:hover {
  text-decoration: underline;
}
  
  
      `;
  return (
    <SyntaxHighlighter language="HTML" style={atomOneDark}>
      {codeString}
    </SyntaxHighlighter>
  );
};
