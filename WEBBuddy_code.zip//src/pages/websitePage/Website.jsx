import React from "react";
import Navbar from "../../component/main_comps/Navbar";
import Navigationtab from "../../component/main_comps/Navigationtab";
import Slider from "../../component/main_comps/Slider";
import "../pages.css";
import ImageContainer from "./ImageContainer";
import Footer from "../../component/main_comps/Footer";

export default function website() {
  return (
    <div>
      {/* <Slider /> */}
      <Navbar />
      <Navigationtab />
      <ImageContainer />
      <Footer />
    </div>
  );
}
