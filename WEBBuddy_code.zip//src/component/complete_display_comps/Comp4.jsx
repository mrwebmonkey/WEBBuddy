import React from "react";

import DropDown from "../provide_comps/dropdown/DropDown";
import DropDownCode from "../provide_comps/dropdown/DropDownCode";
import DropDown2 from "../provide_comps/dropdown/moredropdowns/DropDown2";
import DropDown2Code from "../provide_comps/dropdown/moredropdowns/DropDown2Code";

export default function Comp2() {
  return (
    <div>
      <div className="info-of-component">
        <p>
          Description: Drop-downs allow users to select an option from a list of
          choices. Usage: Form fields, navigation menus, or filter options.
          Features: Support for single/multiple selections, search
          functionality, and custom styling.
        </p>
      </div>
      {/* drop dowm -- 1 */}

      <div className="preview-box">
        <div className="preview-box-head">
          <p>Preview</p>
        </div>
        <div className="preview">
          <DropDown2 />
        </div>
      </div>
      <div className="code-box">
        <div className="code-container-head">
          <p>Code</p>
        </div>
        <div className="code">
          <DropDown2Code />
        </div>
      </div>

      {/* drop down -- 2 */}

      <div className="preview-box">
        <div className="preview-box-head">
          <p>Preview</p>
        </div>
        <div className="preview">
          <DropDown />
        </div>
      </div>
      <div className="code-box">
        <div className="code-container-head">
          <p>Code</p>
        </div>
        <div className="code">
          <DropDownCode />
        </div>
      </div>
    </div>
  );
}
