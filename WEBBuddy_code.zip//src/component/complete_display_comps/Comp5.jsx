import React from "react";

import LoginForm from "../provide_comps/loginForm/LoginForm";
import LoginFormCode from "../provide_comps/loginForm/LoginFormCode";

export default function Comp2() {
  return (
    <div>
      <div className="info-of-component">
        <p>
          Description: A login form collects user credentials (username and
          password) to authenticate users. Usage: Access control for
          applications or websites.
        </p>
      </div>
      <div className="preview-box">
        <div className="preview-box-head">
          <p>Preview</p>
        </div>
        <div className="preview">
          <LoginForm />
        </div>
      </div>
      <div className="code-box">
        <div className="code-container-head">
          <p>Code</p>
        </div>
        <div className="code">
          <LoginFormCode />
        </div>
      </div>
    </div>
  );
}
