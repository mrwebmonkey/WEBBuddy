import React from "react";
import "./MusicMenu.css";

export default function MusicMenu() {
  return (
    <div>
      <div class="music-menu">
        <h1>Music Library</h1>
        <ul class="song-list">
          <li class="song-item">
            <img
              src="https://cdn.pixabay.com/photo/2013/07/13/11/32/disc-158357_1280.png"
              height="100"
              alt="Album Art"
              class="album-art"
            />
            <div class="song-info">
              <h2 class="song-title">Song Title 1</h2>
              <p class="artist-name">Artist 1</p>
            </div>
          </li>
          {/* <li class="song-item">
            <img
              src="https://cdn.pixabay.com/photo/2013/07/13/11/32/disc-158357_1280.png"
              height="100"
              alt="Album Art"
              class="album-art"
            />
            <div class="song-info">
              <h2 class="song-title">Song Title 2</h2>
              <p class="artist-name">Artist 2</p>
            </div>
          </li> */}
        </ul>
      </div>
    </div>
  );
}
