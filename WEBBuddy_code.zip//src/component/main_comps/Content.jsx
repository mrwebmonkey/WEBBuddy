import Button from "../provide_comps/buttons/Button";
import LoginForm from "../provide_comps/loginForm/LoginForm";
import Loader from "../provide_comps/terminalLoder/Loader";
import MusicMenu from "../provide_comps/musicmenu/MusicMenu";
import ProgressBar from "../provide_comps/progressbar/ProgressBar";
import Avatar from "../provide_comps/avatar/Avatar";
import GlowButton from "../provide_comps/hoverbutton/morehoverbutton/glowbutton/GlowButton";

export default function Content() {
  return (
    <div className="content-container">
      <div className="contant-box">
        <Loader />
      </div>
      <div className="contant-box">
        <LoginForm />
      </div>
      <div className="contant-box">
        <div class="card hover-card">
          <h2>Hover Card</h2>
          <p>Hover over this card to see the effect.</p>
        </div>
      </div>
      <div className="contant-box">
        <GlowButton />
      </div>
      <div className="contant-box">
        <ProgressBar />
      </div>
      <div className="contant-box">
        <div class="card image-card">
          <img src="https://via.placeholder.com/150" alt="Placeholder Image" />
          <h2>Image Card</h2>
          <p>This card contains an image.</p>
        </div>
      </div>
      <div className="contant-box">
        <Button />
      </div>
      <div className="contant-box">
        <MusicMenu />
      </div>
      {/* <div className="contant-box">
        <Avatar />
      </div> */}
      {/* <div className="contant-box">
        <Table />
      </div> */}
    </div>
  );
}
