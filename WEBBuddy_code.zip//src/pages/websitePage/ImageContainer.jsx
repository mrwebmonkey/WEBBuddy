import "../pages.css";
import ImageBox from "./ImageBox";
import { Link, Outlet } from "react-router-dom";

export default function ImageContainer() {
  return (
    <div className="container">
      <Link to="/loginpages">
        <ImageBox
          src={
            "https://img.freepik.com/free-vector/template-login-green-background_1017-7451.jpg?ga=GA1.1.259908405.1723487220&semt=ais_hybrid"
          }
        />
      </Link>

      <Link to="/productpages">
        <ImageBox
          src={
            "https://img.freepik.com/premium-vector/product-filled-outline-doodle-design-illustration-symbol-white-background-eps-10-file_848977-343.jpg?ga=GA1.1.259908405.1723487220&semt=ais_hybrid"
          }
        />
      </Link>

      <Link to="/landingpages">
        <ImageBox
          src={
            "https://img.freepik.com/premium-vector/creative-landing-page-design_77399-70.jpg?ga=GA1.1.259908405.1723487220&semt=ais_hybrid"
          }
        />
      </Link>

      <Link to="/Aboutpages">
        <ImageBox
          src={
            "https://img.freepik.com/premium-vector/concept-computer-work-text-typing-posting-colored-flat-vector-illustration-isolated_638785-4060.jpg?ga=GA1.1.259908405.1723487220&semt=ais_hybrid"
          }
        />
      </Link>

      <Link to="/Gallerypages">
        <ImageBox
          src={
            "https://img.freepik.com/free-vector/hand-drawn-flat-design-homepage-illustration_52683-81353.jpg?ga=GA1.1.259908405.1723487220&semt=ais_hybrid"
          }
        />
      </Link>
    </div>
  );
}
