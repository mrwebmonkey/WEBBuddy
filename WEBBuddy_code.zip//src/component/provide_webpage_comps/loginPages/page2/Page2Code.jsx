import SyntaxHighlighter from "react-syntax-highlighter";
import { atomOneDark } from "react-syntax-highlighter/dist/esm/styles/hljs";

export default Page2Code = () => {
  const codeString = `
<!-- HTML Code -->

  <div className="website2">
  <div className="left-container">
    <img
      src="https://img.freepik.com/free-vector/login-concept-illustration_114360-739.jpg?ga=GA1.1.259908405.1723487220&semt=ais_hybrid"
      alt=""
      height="450"
    />
  </div>
  <div className="right-container">
    <h2>Create a New Account</h2>
    <div className="input-box">
      <label>Full Name</label>
      <input type="text" />
      <label>Email Address</label>
      <input type="email" />
      <label>Passward</label>
      <input type="password" />
      <label>Confirm Passward</label>
      <input type="password" />
    </div>
    <br />
    <br />
    <button>Sign Up</button>
    <p>Already have an account ? Log In</p>
  </div>
</div>

<!-- CSS Code -->

* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}
.website2 {
  height: 100vh;
  width: 100%;
  background: rgb(102, 250, 171);
  background: linear-gradient(
    90deg,
    rgba(102, 250, 171, 1) 0%,
    rgba(0, 138, 255, 1) 100%
  );
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 200px;
  padding: 20px;
}
.website2 .left-container {
  display: flex;
  justify-content: center;
  align-items: center;
}
.website2 .right-container {
  background-color: #008aff;
  color: white;
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  gap: 5px;
  padding: 30px;
}
.website2 .right-container .input-box {
  display: flex;
  flex-direction: column;
  gap: 3px;
}
.website2 .right-container input {
  height: 35px;
  width: 300px;
  background: transparent;
  border-top: none;
  border-left: none;
  border-right: none;
  border-bottom: 2px solid white;
}
.website2 .right-container button {
  height: 45px;
  width: 300px;
  font-size: 18px;
  font-weight: 700;
  border-radius: 5px;
  border: none;
  color: white;
  background-color: #0372d3;
}
.website2 .right-container h2 {
  margin-bottom: 30px;
  font-size: 30px;
}

      `;
  return (
    <SyntaxHighlighter language="HTML" style={atomOneDark}>
      {codeString}
    </SyntaxHighlighter>
  );
};
