import SyntaxHighlighter from "react-syntax-highlighter";
import { atomOneDark } from "react-syntax-highlighter/dist/esm/styles/hljs";

export default Page1Code = () => {
  const codeString = `
<!-- HTML Code -->

  <div className="webpage1">
  <div className="left-container">
    <div className="head">
      <div>
        <h3 className="poppins-semibold">Giggling Platypus Co.</h3>
      </div>
      <img
        src="https://img.freepik.com/free-vector/shopping-online-women-with-smartphone-ecommerce_24877-56063.jpg?ga=GA1.1.259908405.1723487220&semt=ais_hybrid"
        alt="hero-image"
        height="450"
      />
    </div>
  </div>
  <div className="right-container">
    <h1 className="poppins-semibold">Happy Shopping</h1>
    <h4>Let's You Sign In !</h4>
    <input className="input-box" type="text" placeholder="Username:" />
    <input className="input-box" type="text" placeholder="Passward:" />
    <button>Get Started</button>
    <div className="info">
      <p>Create Account</p>
      <p>Need Help ?</p>
    </div>
  </div>
</div>

<!-- CSS Code -->

  * {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}
.poppins-semibold {
  font-family: "Poppins", serif;
  font-weight: 600;
  font-style: normal;
}
.webpage1 {
  background-color: red;
  height: 100vh;
  width: ;
  display: flex;
  justify-content: center;
  align-items: center;
}
.webpage1 .left-container {
  width: 50%;
  height: 100%;
  background-color: #cdb4db;
  display: flex;
  justify-content: center;
  align-items: center;
}
.webpage1 .left-container .head {
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  gap: 20px;
}
.webpage1 .left-container .head h3 {
  text-align: left;
  font-size: 20px;
}
.webpage1 .right-container {
  width: 50%;
  height: 100%;
  background-color: #ffc8dd;
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  gap: 40px;
}

.webpage1 .right-container .input-box {
  height: 50px;
  width: 300px;
  border-radius: 22px;
  border: none;
  background-color: #ffafcc;
  padding: 20px;
  color: #000;
}
.webpage1 .right-container h1 {
  font-size: 50px;
}
.webpage1 .right-container button {
  height: 40px;
  width: 200px;
  border-radius: 22px;
  border: none;
  color: #000;
}
.webpage1 .right-container .info {
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 60px;
  color: #000;
}

      `;
  return (
    <SyntaxHighlighter language="HTML" style={atomOneDark}>
      {codeString}
    </SyntaxHighlighter>
  );
};
