export default function () {
  return (
    <div className="hero-text">
      <h1 className="custom-font">
        WEB
        <span className="custom-font-2">Buddy</span>
      </h1>
    </div>
  );
}
