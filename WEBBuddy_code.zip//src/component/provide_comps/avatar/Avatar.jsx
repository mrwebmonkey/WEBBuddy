import "./Avatar.css";

export default function Avatar() {
  return (
    <div>
      <div class="avatar">
        <img
          src="https://img.freepik.com/premium-vector/cartoon-illustration-swat-special-agent_272293-4608.jpg?ga=GA1.1.259908405.1723487220&semt=ais_hybrid"
          alt="User Avatar"
        />
      </div>

      <div class="avatar">JD</div>

      <div class="avatar small">
        <img
          src="https://img.freepik.com/free-vector/young-man-black-shirt_1308-173618.jpg?ga=GA1.1.259908405.1723487220&semt=ais_hybrid"
          alt="User Avatar"
        />
      </div>

      <div class="avatar large">EM</div>
    </div>
  );
}
