import "./DropDown2.css";

export default function () {
  return (
    <div class="dropdown-2">
      <button class="dropdown-btn">Menu</button>
      <div class="dropdown-content">
        <a href="#">Home</a>
        <a href="#">About</a>
        <a href="#">Services</a>
        <a href="#">Contact</a>
      </div>
    </div>
  );
}
