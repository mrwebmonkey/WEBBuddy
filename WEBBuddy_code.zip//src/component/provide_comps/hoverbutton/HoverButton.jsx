import "../hoverbutton/hoverButton.css";

export default function HoverButton() {
  return (
    <div>
      <div class="container">
        <button class="hover-button">Hover Me!</button>
      </div>
    </div>
  );
}
