import "./RippleButton.css";

export default function () {
  return <button class="button-ripple">Hover Me</button>;
}
