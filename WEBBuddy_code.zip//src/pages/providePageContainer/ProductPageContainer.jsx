import { Link } from "react-router-dom";
import Ppage1Code from "../../component/provide_webpage_comps/ProductPages/Ppage1/Ppage1Code";

export default function LandingPageContainer() {
  return (
    <div className="login-page-con-center">
      <div className="page-center">
        <Link to="/Productgpage1">
          <div className="page-container">
            <img
              src="http://127.0.0.1:5500/media/productpage-1.png"
              alt="login-page"
              height="520"
              width="900"
            />
          </div>
        </Link>
        <div className="code-container-2">
          <Ppage1Code />
        </div>
      </div>
    </div>
  );
}
