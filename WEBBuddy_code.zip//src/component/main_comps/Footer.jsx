export default function Footer() {
  return (
    <div className="footer">
      <div className="footer-box">
        <div className="logo-box">
          <p className="custom-font">Terms | FAQ | Help | Privacy Policy</p>
          <div className="logo-container">
            <div className="logo"></div>
            <div className="logo"></div>
            <div className="logo"></div>
            <div className="logo"></div>
          </div>
        </div>
      </div>
      <div className="footer-box">
        <div className="box">
          <input
            className="custom-font"
            type="email"
            placeholder="Enter your email"
          />
          <button className="custom-font">SUBMIT</button>
        </div>
        <div className="box2">
          <input type="checkbox" />
          <p className="custom-font">
            Allow this site to notify you when we <br /> add new components.
          </p>
        </div>
      </div>
    </div>
  );
}
