import React from "react";
import "../cards/Card.css";

export default function Card() {
  return (
    <div>
      <div class="container">
        <div class="card">
          <h2>Basic Card</h2>
          <p>This is a simple card with some text.</p>
        </div>

        <div class="card image-card">
          <img src="https://via.placeholder.com/150" alt="Placeholder Image" />
          <h2>Image Card</h2>
          <p>This card contains an image.</p>
        </div>

        <div class="card hover-card">
          <h2>Hover Card</h2>
          <p>Hover over this card to see the effect.</p>
        </div>
      </div>
    </div>
  );
}
