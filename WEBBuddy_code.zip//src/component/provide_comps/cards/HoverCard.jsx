import "./HoverCard.css";

export default function () {
  return (
    <div class="main-container">
      <div class="hover-card-2" id="c1"></div>
      <div class="hover-card-2" id="c2"></div>
      <div class="hover-card-2" id="c3"></div>
      <div class="hover-card-2" id="c4"></div>
    </div>
  );
}
