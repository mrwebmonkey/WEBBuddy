import SyntaxHighlighter from "react-syntax-highlighter";
import { atomOneDark } from "react-syntax-highlighter/dist/esm/styles/hljs";

export default Component = () => {
  const codeString = `
  <!-- HTML Code -->

  <button class="button-glow">Hover Me</button>
  
  <!-- CSS Code -->

  .button-glow {
    color: #fff;
    background: linear-gradient(90deg, #ff6a00, #ee0979);
    border: none;
    border-radius: 25px;
    padding: 15px 30px;
    font-size: 18px;
    cursor: pointer;
    text-transform: uppercase;
    position: relative;
    overflow: hidden;
    box-shadow: 0 4px 15px rgba(255, 106, 0, 0.5);
    transition: box-shadow 0.3s ease, transform 0.3s ease;
  }
  .button-glow:hover {
    transform: scale(1.05);
    box-shadow: 0 6px 20px rgba(255, 106, 0, 0.7);
  }
  
      `;
  return (
    <div className="code-container">
      <SyntaxHighlighter language="HTML" style={atomOneDark}>
        {codeString}
      </SyntaxHighlighter>
    </div>
  );
};
