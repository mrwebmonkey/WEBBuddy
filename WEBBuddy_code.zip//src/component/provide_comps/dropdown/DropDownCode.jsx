import SyntaxHighlighter from "react-syntax-highlighter";
import { atomOneDark } from "react-syntax-highlighter/dist/esm/styles/hljs";

export default Component = () => {
  const codeString = `
  <!-- HTML Code -->

  <nav>
  <ul class="menu">
    <li>Home</li>
    <li>About</li>
    <li>
      Services
      <ul class="dropdown">
        <li>
          Web Design
          <ul class="dropdown">
            <li>Responsive Design</li>
            <li>UI/UX Design</li>
          </ul>
        </li>
        <li>SEO</li>
        <li>Marketing</li>
      </ul>
    </li>
    <li>Contact</li>
  </ul>
</nav>

<!-- CSS Code -->

  nav {
    background-color: #333;
  }
  
  .menu {
    list-style-type: none;
    padding: 0;
    margin: 0;
  }
  
  .menu > li {
    display: inline-block;
    position: relative;
    padding: 15px 20px;
    color: white;
  }
  
  .menu > li:hover {
    background-color: #555;
  }
  
  .dropdown {
    display: none;
    position: absolute;
    background-color: #444;
    min-width: 160px;
    list-style-type: none;
    padding: 0;
    margin: 0;
  }
  
  .menu > li:hover .dropdown {
    display: block;
  }
  
  .dropdown li {
    padding: 12px 16px;
    color: white;
    position: relative;
  }
  
  .dropdown li:hover {
    background-color: #555;
  }
  
  .dropdown .dropdown {
    top: 0;
    left: 100%;
    margin-top: -1px; /* Aligns the nested dropdown */
  }
  

 `;
  return (
    <div className="code-container">
      <SyntaxHighlighter language="HTML" style={atomOneDark}>
        {codeString}
      </SyntaxHighlighter>
    </div>
  );
};
