import SyntaxHighlighter from "react-syntax-highlighter";
import { atomOneDark } from "react-syntax-highlighter/dist/esm/styles/hljs";

export default GPpage1Code = () => {
  const codeString = `
<!-- HTML Code -->

      <header>
        <h1>Project Gallery</h1>
        <p>Explore the collection of my creative projects.</p>
      </header>

      <section class="gallery">
        <div class="gallery-item">
          <img
            src="https://img.freepik.com/free-vector/new-normal-museums-concept_23-2148587884.jpg?ga=GA1.1.259908405.1723487220&semt=ais_hybrid"
            alt="Project 1"
          />
          <div class="info">
            <h2>Project 1</h2>
            <p>Description of the first project.</p>
          </div>
        </div>
        <div class="gallery-item">
          <img
            src="https://img.freepik.com/free-vector/new-normal-museums_23-2148575036.jpg?ga=GA1.1.259908405.1723487220&semt=ais_hybrid"
            alt="Project 2"
          />
          <div class="info">
            <h2>Project 2</h2>
            <p>Description of the second project.</p>
          </div>
        </div>
        <div class="gallery-item">
          <img
            src="https://img.freepik.com/free-vector/new-normal-museums-concept_23-2148587008.jpg?ga=GA1.1.259908405.1723487220&semt=ais_hybrid"
            alt="Project 3"
          />
          <div class="info">
            <h2>Project 3</h2>
            <p>Description of the third project.</p>
          </div>
        </div>
        <div class="gallery-item">
          <img
            src="https://img.freepik.com/free-vector/new-normal-museums-concept_23-2148587884.jpg?ga=GA1.1.259908405.1723487220&semt=ais_hybrid"
            alt="Project 1"
          />
          <div class="info">
            <h2>Project 1</h2>
            <p>Description of the first project.</p>
          </div>
        </div>
        <div class="gallery-item">
          <img
            src="https://img.freepik.com/free-vector/new-normal-museums-concept_23-2148587884.jpg?ga=GA1.1.259908405.1723487220&semt=ais_hybrid"
            alt="Project 1"
          />
          <div class="info">
            <h2>Project 1</h2>
            <p>Description of the first project.</p>
          </div>
        </div>
        <div class="gallery-item">
          <img
            src="https://img.freepik.com/free-vector/new-normal-museums-concept_23-2148587884.jpg?ga=GA1.1.259908405.1723487220&semt=ais_hybrid"
            alt="Project 1"
          />
          <div class="info">
            <h2>Project 1</h2>
            <p>Description of the first project.</p>
          </div>
        </div>
        <div class="gallery-item">
          <img
            src="https://img.freepik.com/free-vector/new-normal-museums-concept_23-2148587008.jpg?ga=GA1.1.259908405.1723487220&semt=ais_hybrid"
            alt="Project 3"
          />
          <div class="info">
            <h2>Project 3</h2>
            <p>Description of the third project.</p>
          </div>
        </div>
        <div class="gallery-item">
          <img
            src="https://img.freepik.com/free-vector/new-normal-museums-concept_23-2148587008.jpg?ga=GA1.1.259908405.1723487220&semt=ais_hybrid"
            alt="Project 3"
          />
          <div class="info">
            <h2>Project 3</h2>
            <p>Description of the third project.</p>
          </div>
        </div>
      </section>

      <footer>
        <p>&copy; 2024 My Projects Gallery</p>
      </footer>

<!-- CSS Code -->

header {
    text-align: center;
    padding: 20px;
    background-color: #ff006e;
    color: white;
  }
  
  header h1 {
    margin: 0;
    font-size: 2.5rem;
  }
  
  header p {
    margin: 10px 0 0;
    font-size: 1.2rem;
  }
  
  .gallery {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 20px;
    padding: 20px;
    max-width: 1200px;
    margin: 0 auto;
  }
  
  .gallery-item {
    position: relative;
    overflow: hidden;
    border-radius: 10px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  }
  
  .gallery-item img {
    width: 100%;
    height: auto;
    display: block;
    transition: transform 0.3s ease;
  }
  
  .gallery-item:hover img {
    transform: scale(1.1);
  }
  
  .info {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    background-color: rgba(0, 0, 0, 0.6);
    color: white;
    opacity: 0;
    transition: opacity 0.3s ease;
    text-align: center;
    padding: 20px;
  }
  
  .gallery-item:hover .info {
    opacity: 1;
  }
  
  .info h2 {
    margin: 0;
    font-size: 1.5rem;
  }
  
  .info p {
    margin: 10px 0 0;
    font-size: 1rem;
  }
  
  footer {
    text-align: center;
    padding: 10px;
    background-color: #333;
    color: white;
    font-size: 0.9rem;
  }
  
      `;
  return (
    <SyntaxHighlighter language="HTML" style={atomOneDark}>
      {codeString}
    </SyntaxHighlighter>
  );
};
