import React from "react";
import { NavLink } from "react-router-dom";

import "../pages.css";
import Footer from "../../component/main_comps/Footer";
import OptionsComp from "./OptionsComp";
import Comp0 from "../../component/complete_display_comps/Comp0";
import Comp1 from "../../component/complete_display_comps/Comp1";
import Comp2 from "../../component/complete_display_comps/Comp2";
import Comp3 from "../../component/complete_display_comps/Comp3";
import Comp4 from "../../component/complete_display_comps/Comp4";
import Comp5 from "../../component/complete_display_comps/Comp5";
import Comp7 from "../../component/complete_display_comps/Comp7";
import Comp8 from "../../component/complete_display_comps/Comp8";
import Comp9 from "../../component/complete_display_comps/Comp9";
import Comp10 from "../../component/complete_display_comps/Comp10";
import Comp11 from "../../component/complete_display_comps/Comp11";

const items = [
  "How To Use ?",
  "Simple button",
  "Hover button",
  "Cards",
  "Drop-down",
  "Login form",
  "Terminal loader",
  "Music menu",
  "Progress Bar",
  "Table",
  "Avatar's",
];

function RenderComp({ index }) {
  switch (index) {
    case 0:
      return <Comp0 />;
      break;
    case 1:
      return <Comp1 />;
      break;
    case 2:
      return <Comp2 />;
      break;
    case 3:
      return <Comp3 />;
      break;
    case 4:
      return <Comp4 />;
      break;
    case 5:
      return <Comp5 />;
      break;
    case 6:
      return <Comp7 />;
      break;
    case 7:
      return <Comp8 />;
      break;
    case 8:
      return <Comp9 />;
      break;
    case 9:
      return <Comp10 />;
      break;
    case 10:
      return <Comp11 />;
      break;
    default:
      break;
  }
}

export default function Components() {
  const [isSelect, setIsSelect] = React.useState(0);
  return (
    <div className="component-page">
      <div className="centre">
        <div className="left-side">
          <OptionsComp
            items={items}
            isSelect={isSelect}
            setIsSelect={setIsSelect}
          />
        </div>
        <div className="right-side custom-font">
          <RenderComp index={isSelect} />
        </div>
      </div>
      <Footer />
    </div>
  );
}
