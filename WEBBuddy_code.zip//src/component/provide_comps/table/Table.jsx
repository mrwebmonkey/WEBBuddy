import "./Table.css";

export default function Table() {
  return (
    <div class="table-container">
      <table>
        <thead>
          <tr>
            <th>#</th>
            <th>Name</th>
            <th>Email</th>
            <th>Role</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>1</td>
            <td>Jane Doe</td>
            <td>jane.doe@example.com</td>
            <td>Admin</td>
          </tr>
          <tr>
            <td>2</td>
            <td>John Smith</td>
            <td>john.smith@example.com</td>
            <td>Editor</td>
          </tr>
          <tr>
            <td>3</td>
            <td>Emily Johnson</td>
            <td>emily.johnson@example.com</td>
            <td>Viewer</td>
          </tr>
        </tbody>
      </table>
    </div>
  );
}
