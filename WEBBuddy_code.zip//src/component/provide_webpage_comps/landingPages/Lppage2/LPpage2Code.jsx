import SyntaxHighlighter from "react-syntax-highlighter";
import { atomOneDark } from "react-syntax-highlighter/dist/esm/styles/hljs";

export default LPpage1Code = () => {
  const codeString = `
<!-- HTML Code -->

  <!-- Navbar -->
  <header class="header">
    <nav class="lp-2-navbar">
      <div class="logo">Creative<span>Space</span></div>
      <ul class="nav-links">
        <li><a href="#services">Services</a></li>
        <li><a href="#portfolio">Portfolio</a></li>
        <li><a href="#contact">Contact</a></li>
      </ul>
      <button class="cta-button">Get Started</button>
    </nav>
  </header>

  <!-- Hero Section -->
  <section class="hero">
    <div class="hero-content">
      <h1>
        Unleashing <span>Creativity</span> in Every Pixel
      </h1>
      <p>
        Transform your ideas into visually stunning designs with our innovative approach to creativity.
      </p>
      <button class="cta-button">Learn More</button>
    </div>
    <div class="hero-image">
      <img src="hero-image.jpg" alt="Creative Workspace">
    </div>
  </section>

  <!-- Services Section -->
  <section id="services" class="services">
    <h2>What I Offer</h2>
    <div class="services-container">
      <div class="service">
        <h3>UI/UX Design</h3>
        <p>Crafting seamless user experiences with clean and intuitive interfaces.</p>
      </div>
      <div class="service">
        <h3>Graphic Design</h3>
        <p>Bringing ideas to life with vibrant, eye-catching visuals.</p>
      </div>
      <div class="service">
        <h3>Branding</h3>
        <p>Helping businesses build strong, memorable brands.</p>
      </div>
    </div>
  </section>

  <!-- Portfolio Section -->
  <section id="portfolio" class="portfolio">
    <h2>My Work</h2>
    <div class="portfolio-grid">
      <div class="portfolio-item">
        <img src="portfolio1.jpg" alt="Project 1">
        <h3>Project Name 1</h3>
      </div>
      <div class="portfolio-item">
        <img src="portfolio2.jpg" alt="Project 2">
        <h3>Project Name 2</h3>
      </div>
      <div class="portfolio-item">
        <img src="portfolio3.jpg" alt="Project 3">
        <h3>Project Name 3</h3>
      </div>
    </div>
  </section>

  <!-- Footer -->
  <footer class="footer">
    <div class="footer-content">
      <p>&copy; 2024 CreativeSpace. All Rights Reserved.</p>
      <ul class="footer-links">
        <li><a href="#services">Services</a></li>
        <li><a href="#portfolio">Portfolio</a></li>
        <li><a href="#contact">Contact</a></li>
      </ul>
    </div>
  </footer>

<!-- CSS Code -->

  /* General Reset */
  * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
  }
  
  body {
    font-family: "Poppins", sans-serif;
    line-height: 1.6;
    background: #f9f9f9;
    color: #333;
  }
  
  /* Navbar */
  .lp-2-navbar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 1.5rem 2rem;
    background: linear-gradient(90deg, #6a11cb, #2575fc);
    color: #fff;
  }
  
  .logo {
    font-size: 1.8rem;
    font-weight: bold;
  }
  
  .logo span {
    color: #ffe084;
  }
  
  .nav-links {
    display: flex;
    list-style: none;
  }
  
  .nav-links li {
    margin: 0 1rem;
  }
  
  .nav-links a {
    text-decoration: none;
    color: #fff;
    font-weight: 600;
  }
  
  .cta-button {
    padding: 0.6rem 1.5rem;
    background: #ffe084;
    color: #333;
    border: none;
    border-radius: 30px;
    font-weight: bold;
    cursor: pointer;
    transition: transform 0.3s ease, background-color 0.3s ease;
  }
  
  .cta-button:hover {
    background: #ffc556;
    transform: scale(1.1);
  }
  
  /* Hero Section */
  .hero {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 4rem 2rem;
    background: linear-gradient(135deg, #6a11cb, #2575fc);
    color: #fff;
  }
  
  .hero-content {
    max-width: 600px;
  }
  
  .hero-content h1 {
    font-size: 3rem;
    margin-bottom: 1.5rem;
  }
  
  .hero-content h1 span {
    color: #ffe084;
  }
  
  .hero-content p {
    font-size: 1.2rem;
    margin-bottom: 1.5rem;
  }
  
  .hero-image img {
    width: 100%;
    max-width: 500px;
    border-radius: 20px;
  }
  
  /* Services Section */
  .services {
    padding: 3rem 2rem;
    text-align: center;
    background: #f9f9f9;
  }
  
  .services h2 {
    font-size: 2.5rem;
    margin-bottom: 2rem;
  }
  
  .services-container {
    display: flex;
    gap: 2rem;
    justify-content: center;
    flex-wrap: wrap;
  }
  
  .service {
    background: #fff;
    border-radius: 10px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    padding: 2rem;
    max-width: 300px;
    transition: transform 0.3s ease;
  }
  
  .service:hover {
    transform: scale(1.05);
  }
  
  /* Portfolio Section */
  .portfolio {
    padding: 3rem 2rem;
    background: #e4ecfa;
  }
  
  .portfolio h2 {
    text-align: center;
    font-size: 2.5rem;
    margin-bottom: 2rem;
  }
  
  .portfolio-grid {
    display: flex;
    gap: 1.5rem;
    justify-content: center;
    flex-wrap: wrap;
  }
  
  .portfolio-item {
    background: #fff;
    border-radius: 10px;
    padding: 1rem;
    text-align: center;
    transition: transform 0.3s ease;
  }
  
  .portfolio-item:hover {
    transform: scale(1.05);
  }
  
  .portfolio-item img {
    width: 100%;
    border-radius: 10px;
    margin-bottom: 1rem;
  }
  
  /* Footer */
  .footer {
    padding: 2rem;
    background: #333;
    color: #fff;
    text-align: center;
  }
  
  .footer-links {
    list-style: none;
    margin-top: 1rem;
    display: flex;
    justify-content: center;
    gap: 1rem;
  }
  
  .footer-links a {
    color: #fff;
    text-decoration: none;
    font-weight: 600;
  }
  
  
      `;
  return (
    <SyntaxHighlighter language="HTML" style={atomOneDark}>
      {codeString}
    </SyntaxHighlighter>
  );
};
