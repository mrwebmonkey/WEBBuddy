import SyntaxHighlighter from "react-syntax-highlighter";
import { atomOneDark } from "react-syntax-highlighter/dist/esm/styles/hljs";

export default Component = () => {
  const codeString = `
  <!-- HTML Code -->

  <button class="button-ripple">Hover Me</button>
  
  <!-- CSS Code -->

  .button-ripple {
    color: #fff;
    background: #ff007f;
    border: none;
    border-radius: 50px;
    padding: 15px 40px;
    font-size: 18px;
    cursor: pointer;
    position: relative;
    overflow: hidden;
    transition: background 0.3s ease;
  }
  .button-ripple:hover {
    background: #d1006f;
  }
  .button-ripple::after {
    content: "";
    position: absolute;
    width: 300%;
    height: 300%;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%) scale(0);
    background: rgba(255, 255, 255, 0.5);
    border-radius: 50%;
    transition: transform 0.6s ease, opacity 0.6s ease;
    opacity: 0;
  }
  .button-ripple:hover::after {
    transform: translate(-50%, -50%) scale(1);
    opacity: 1;
  }
  
      `;
  return (
    <div className="code-container">
      <SyntaxHighlighter language="HTML" style={atomOneDark}>
        {codeString}
      </SyntaxHighlighter>
    </div>
  );
};
