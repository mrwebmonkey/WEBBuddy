import "./SlideButton.css";

export default function () {
  return <button class="button-slide">Hover Me</button>;
}
