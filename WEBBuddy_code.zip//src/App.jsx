import { BrowserRouter, Route, Routes } from "react-router-dom";

import HomePage from "./pages/HomePage";
import Components from "./pages/componentsPage/Components";
import Website from "./pages/websitePage/Website";
import AboutPage from "./pages/AboutPage";
import ErrorPage from "./pages/ErrorPage";

import LoginPageContainer from "./pages/providePageContainer/LoginPageContainer";
import LandingPageContainer from "./pages/providePageContainer/LandingPageContainer";
import ProductPageContainer from "./pages/providePageContainer/ProductPageContainer";
import AboutPageContainer from "./pages/providePageContainer/AboutPageContainer";
import GalleryPageContainer from "./pages/providePageContainer/GalleryPageContainer";

import Page1 from "./component/provide_webpage_comps/loginPages/page1/Page1";
import Page2 from "./component/provide_webpage_comps/loginPages/page2/Page2";
import LPpage1 from "./component/provide_webpage_comps/landingPages/LPpage1/LPpage1";
import LPpage2 from "./component/provide_webpage_comps/landingPages/Lppage2/LPpage2";
import Ppage1 from "./component/provide_webpage_comps/ProductPages/Ppage1/Ppage1";
import Apage1 from "./component/provide_webpage_comps/AboutPages/Apage1";
import GPpage1 from "./component/provide_webpage_comps/GalleryPages/GPpage1/GPpage1";

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/components" element={<Components />} />
        <Route path="/website" element={<Website />} />
        <Route path="/about" element={<AboutPage />} />

        <Route path="/loginpages" element={<LoginPageContainer />} />
        <Route path="/landingpages" element={<LandingPageContainer />} />
        <Route path="/productpages" element={<ProductPageContainer />} />
        <Route path="/Aboutpages" element={<AboutPageContainer />} />
        <Route path="/Gallerypages" element={<GalleryPageContainer />} />

        <Route path="/loginpage1" element={<Page1 />} />
        <Route path="/loginpage2" element={<Page2 />} />

        <Route path="/landingpage1" element={<LPpage1 />} />
        <Route path="/landingpage2" element={<LPpage2 />} />

        <Route path="/Productgpage1" element={<Ppage1 />} />

        <Route path="/Aboutpage1" element={<Apage1 />} />

        <Route path="/Gallerypage1" element={<GPpage1 />} />

        <Route path="*" element={<ErrorPage />} />
      </Routes>
    </BrowserRouter>
  );
}
