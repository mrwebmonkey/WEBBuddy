import SyntaxHighlighter from "react-syntax-highlighter";
import { atomOneDark } from "react-syntax-highlighter/dist/esm/styles/hljs";

export default Component = () => {
  const codeString = `
<!-- HTML Code -->

  <div class="table-container">
  <table>
    <thead>
      <tr>
        <th>#</th>
        <th>Name</th>
        <th>Email</th>
        <th>Role</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>1</td>
        <td>Jane Doe</td>
        <td>jane.doe@example.com</td>
        <td>Admin</td>
      </tr>
      <tr>
        <td>2</td>
        <td>John Smith</td>
        <td>john.smith@example.com</td>
        <td>Editor</td>
      </tr>
      <tr>
        <td>3</td>
        <td>Emily Johnson</td>
        <td>emily.johnson@example.com</td>
        <td>Viewer</td>
      </tr>
    </tbody>
  </table>
</div>

<!-- CSS Code-->

.table-container {
    overflow-x: auto;
  }
  
  table {
    width: 80%;
    border-collapse: collapse;
    margin: 20px 0;
    font-size: 16px;
    text-align: left;
  }
  
  th,
  td {
    padding: 12px 15px;
  }
  
  thead tr {
    background-color: #4caf50;
    color: #ffffff;
    text-align: left;
  }
  
  tbody tr:nth-child(even) {
    background-color: #f2f2f2;
  }
  
  tbody tr:hover {
    background-color: #d1e7dd;
    cursor: pointer;
  }
  
  table,
  th,
  td {
    border: 1px solid #dddddd;
  }
  
  /* Responsive design */
  @media (max-width: 600px) {
    table {
      font-size: 14px;
    }
  
    th,
    td {
      padding: 10px;
    }
}

      `;
  return (
    <div className="code-container">
      <SyntaxHighlighter language="HTML" style={atomOneDark}>
        {codeString}
      </SyntaxHighlighter>
    </div>
  );
};
