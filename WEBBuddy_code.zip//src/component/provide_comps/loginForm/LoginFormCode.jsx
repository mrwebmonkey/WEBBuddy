import SyntaxHighlighter from "react-syntax-highlighter";
import { atomOneDark } from "react-syntax-highlighter/dist/esm/styles/hljs";

export default Component = () => {
  const codeString = `
  <!-- HTML Code -->

  <div class="login-container">
        <form class="login-form">
          <h2>Login</h2>
          <div class="input-container">
            <input type="text" id="username" required />
            <label for="username">Username</label>
          </div>
          <div class="input-container">
            <input type="password" id="password" required />
            <label for="password">Password</label>
          </div>
          <button type="submit">Login</button>
        </form>
      </div>
  
  <!-- CSS Code -->

  .login-container {
    background-color: white;
    border-radius: 8px;
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
    padding: 20px;
    width: 300px;
  }
  
  .login-form h2 {
    margin-bottom: 20px;
    text-align: center;
  }
  
  .input-container {
    position: relative;
    margin-bottom: 20px;
  }
  
  .input-container input {
    width: 100%;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 4px;
    font-size: 16px;
    transition: border-color 0.3s ease;
  }
  
  .input-container label {
    position: absolute;
    top: 10px;
    left: 10px;
    font-size: 16px;
    color: #aaa;
    transition: 0.3s;
    pointer-events: none;
  }
  
  .input-container input:focus {
    border-color: #007bff;
  }
  
  .input-container input:focus + label,
  .input-container input:not(:placeholder-shown) + label {
    top: -10px;
    left: 10px;
    font-size: 12px;
    color: #007bff;
  }
  
  button {
    width: 100%;
    padding: 10px;
    background-color: #007bff;
    color: white;
    border: none;
    border-radius: 4px;
    font-size: 16px;
    cursor: pointer;
    transition: background-color 0.3s ease;
  }
  
  button:hover {
    background-color: #0056b3;
  }
  
      `;
  return (
    <div className="code-container">
      <SyntaxHighlighter language="HTML" style={atomOneDark}>
        {codeString}
      </SyntaxHighlighter>
    </div>
  );
};
