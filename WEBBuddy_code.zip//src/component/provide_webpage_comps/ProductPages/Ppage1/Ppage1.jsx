import React from "react";
import "./Ppage1.css";

const ProductPage = () => {
  return (
    <div>
      {/* Navbar */}
      <header className="header">
        <nav className="product-page-navbar">
          <div className="logo">
            Brand<span>Store</span>
          </div>
          <ul className="nav-links">
            <li>
              <a href="#features">Features</a>
            </li>
            <li>
              <a href="#pricing">Pricing</a>
            </li>
            <li>
              <a href="#reviews">Reviews</a>
            </li>
          </ul>
          <button className="cta-button">Sign Up</button>
        </nav>
      </header>

      {/* Product Section */}
      <section className="product">
        <div className="product-image">
          <img
            src="https://img.freepik.com/free-vector/gradient-mobile-store-logo-design_23-2149699859.jpg?ga=GA1.1.259908405.1723487220&semt=ais_hybrid"
            alt="Smart Gadget Pro"
          />
        </div>
        <div className="product-details">
          <h1>Smart Gadget Pro</h1>
          <p>
            Experience cutting-edge technology with the Smart Gadget Pro.
            Perfect for staying connected, tracking your fitness, and making
            everyday tasks easier.
          </p>
          <h3>Key Features:</h3>
          <ul>
            <li>High-resolution touch display</li>
            <li>24/7 heart rate and fitness tracking</li>
            <li>Waterproof and lightweight design</li>
            <li>Seamless integration with all devices</li>
          </ul>
          <h2 className="price">$249.99</h2>
          <button className="buy-button">Buy Now</button>
          <button className="learn-button">Learn More</button>
        </div>
      </section>

      {/* Reviews Section */}
      <section id="reviews" className="reviews">
        <h2>What Our Customers Say</h2>
        <div className="review-card">
          <p>
            "The Smart Gadget Pro has completely transformed my daily routine.
            It's a must-have!"
          </p>
          <h4>- Alex J.</h4>
        </div>
        <div className="review-card">
          <p>
            "Amazing features and sleek design. Highly recommend this product!"
          </p>
          <h4>- Sarah K.</h4>
        </div>
      </section>

      {/* Footer */}
      <footer className="footer">
        <p>&copy; 2024 BrandStore. All Rights Reserved.</p>
        <ul className="footer-links">
          <li>
            <a href="#features">Features</a>
          </li>
          <li>
            <a href="#pricing">Pricing</a>
          </li>
          <li>
            <a href="#reviews">Reviews</a>
          </li>
        </ul>
      </footer>
    </div>
  );
};

export default ProductPage;
