import "./Page1.css";

export default function Page1() {
  return (
    <div className="webpage1">
      <div className="left-container">
        <div className="head">
          <div>
            <h3 className="poppins-semibold">Giggling Platypus Co.</h3>
          </div>
          <img
            src="https://img.freepik.com/free-vector/shopping-online-women-with-smartphone-ecommerce_24877-56063.jpg?ga=GA1.1.259908405.1723487220&semt=ais_hybrid"
            alt="hero-image"
            height="450"
          />
        </div>
      </div>
      <div className="right-container">
        <h1 className="poppins-semibold">Happy Shopping</h1>
        <h4>Let's You Sign In !</h4>
        <input className="input-box" type="text" placeholder="Username:" />
        <input className="input-box" type="text" placeholder="Passward:" />
        <button>Get Started</button>
        <div className="info">
          <p>Create Account</p>
          <p>Need Help ?</p>
        </div>
      </div>
    </div>
  );
}
