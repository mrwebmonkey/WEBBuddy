import "./LPpage1.css";

import React from "react";

const PortfolioLandingPage = () => {
  return (
    <div>
      {/* Navbar */}
      <header>
        <nav className="lp-navbar">
          <div className="logo">
            Design<span>Studio</span>
          </div>
          <ul className="nav-links">
            <li>
              <a href="#about">About</a>
            </li>
            <li>
              <a href="#projects">Projects</a>
            </li>
            <li>
              <a href="#contact">Contact</a>
            </li>
          </ul>
          <button className="cta-button">Hire Me</button>
        </nav>
      </header>

      {/* Hero Section */}
      <section className="hero">
        <div className="hero-text">
          <h1>
            Design Your Vision
            <br />
            <span>With Creativity</span>
          </h1>
          <p>
            Creating bold, dynamic, and innovative designs that captivate and
            inspire.
          </p>
          <button className="cta-button">Explore Portfolio</button>
        </div>
        <div className="hero-image">
          <img src="designer-hero.jpg" alt="Designer at Work" />
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="about">
        <h2>About Me</h2>
        <p>
          I’m a creative designer with expertise in UI/UX, branding, and visual
          storytelling. My goal is to turn ideas into experiences.
        </p>
      </section>

      {/* Projects Section */}
      <section id="projects" className="projects">
        <h2>My Projects</h2>
        <div className="project-gallery">
          <div className="project-item">
            <img src="project1.jpg" alt="Project 1" />
            <h3>Branding Identity</h3>
          </div>
          <div className="project-item">
            <img src="project2.jpg" alt="Project 2" />
            <h3>UI/UX Design</h3>
          </div>
          <div className="project-item">
            <img src="project3.jpg" alt="Project 3" />
            <h3>Creative Art</h3>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="contact">
        <h2>Contact Me</h2>
        <p>
          Let’s bring your ideas to life. Reach out for collaborations or
          inquiries.
        </p>
        <form action="submit-form" method="post" className="contact-form">
          <input type="text" name="name" placeholder="Your Name" required />
          <input type="email" name="email" placeholder="Your Email" required />
          <textarea
            name="message"
            rows="5"
            placeholder="Your Message"
            required
          ></textarea>
          <button type="submit" className="cta-button">
            Send Message
          </button>
        </form>
      </section>

      {/* Footer */}
      <footer>
        <p>&copy; 2024 DesignStudio. All Rights Reserved.</p>
      </footer>
    </div>
  );
};

export default PortfolioLandingPage;
