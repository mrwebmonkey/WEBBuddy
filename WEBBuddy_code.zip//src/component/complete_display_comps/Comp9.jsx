import React from "react";

import ProgressBar from "../provide_comps/progressbar/ProgressBar";
import ProgressBarCode from "../provide_comps/progressbar/ProgressBarCode";

export default function Comp2() {
  return (
    <div>
      <div className="info-of-component">
        <p>
          A progress bar is a graphical user interface element designed to
          visually communicate the status of a task to users. Its primary
          purpose is to provide feedback on the progress of an operation,
          helping users gauge how much of a task is completed and how much
          remains.
        </p>
      </div>
      <div className="preview-box">
        <div className="preview-box-head">
          <p>Preview</p>
        </div>
        <div className="preview">
          <ProgressBar />
        </div>
      </div>
      <div className="code-box">
        <div className="code-container-head">
          <p>Code</p>
        </div>
        <div className="code">
          <ProgressBarCode />
        </div>
      </div>
    </div>
  );
}
