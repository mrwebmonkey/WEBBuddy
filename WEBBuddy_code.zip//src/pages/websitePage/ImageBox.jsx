import React from "react";
import "../pages.css";

export default function ImageBox(props) {
  return (
    <div className="image-box">
      <img src={props.src} alt="content-imgae" height="250" />
    </div>
  );
}
