import React from "react";

import Slider from "../component/main_comps/Slider";
import Navbar from "../component/main_comps/Navbar";
import Herotext from "../component/main_comps/Herotext";
import Navigationtab from "../component/main_comps/Navigationtab";
import Content from "../component/main_comps/Content";
import Footer from "../component/main_comps/Footer";

export default function HomePage() {
  return (
    <div>
      {/* <Slider /> */}
      <Navbar />
      {/* <Herotext /> */}
      <Navigationtab />
      <Content />
      <Footer />
    </div>
  );
}
