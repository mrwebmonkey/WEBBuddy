import React from "react";
import "../dropdown/DropDown.css";

export default function DropDown() {
  return (
    <div>
      <nav>
        <ul class="menu">
          <li>Home</li>
          <li>About</li>
          <li>
            Services
            <ul class="dropdown">
              <li>
                Web Design
                <ul class="dropdown">
                  <li>Responsive Design</li>
                  <li>UI/UX Design</li>
                </ul>
              </li>
              <li>SEO</li>
              <li>Marketing</li>
            </ul>
          </li>
          <li>Contact</li>
        </ul>
      </nav>
    </div>
  );
}
