import SyntaxHighlighter from "react-syntax-highlighter";
import { atomOneDark } from "react-syntax-highlighter/dist/esm/styles/hljs";

export default Component = () => {
  const codeString = `
  <!-- HTML Code -->

  <div class="button-container">
        <button class="btn primary">Primary Button</button>
        <button class="btn secondary">Secondary Button</button>
        <button class="btn danger">Danger Button</button>
  </div>

  <!-- CSS Code -->

  .button-container {
    display: flex;
    flex-direction: column;
    gap: 27px;
  }
  
  .btn {
    height: 56px;
    width: 240px;
    padding: 10px 20px;
    border: none;
    border-radius: 5px;
    color: white;
    cursor: pointer;
    font-size: 16px;
    transition: background-color 0.3s ease, transform 0.2s ease;
  }
  
  .primary {
    background-color: #007bff; /* Bootstrap primary color */
  }
  
  .secondary {
    background-color: #6c757d; /* Bootstrap secondary color */
  }
  
  .danger {
    background-color: #dc3545; /* Bootstrap danger color */
  }
  
  .btn:hover {
    transform: translateY(-2px);
  }
  
  .primary:hover {
    background-color: #0056b3; /* Darker shade for primary */
  }
  
  .secondary:hover {
    background-color: #5a6268; /* Darker shade for secondary */
  }
  
  .danger:hover {
    background-color: #c82333; /* Darker shade for danger */
  }
  
      `;
  return (
    <div className="code-container">
      <SyntaxHighlighter language="HTML" style={atomOneDark}>
        {codeString}
      </SyntaxHighlighter>
    </div>
  );
};
