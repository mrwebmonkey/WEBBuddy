import SyntaxHighlighter from "react-syntax-highlighter";
import { atomOneDark } from "react-syntax-highlighter/dist/esm/styles/hljs";

export default Component = () => {
  const codeString = `
<!-- HTML Code -->

<div class="main-container">
    <div class="hover-card-2" id="c1"></div>
    <div class="hover-card-2" id="c2"></div>
    <div class="hover-card-2" id="c3"></div>
    <div class="hover-card-2" id="c4"></div>
</div>
  
<!-- CSS Code -->

.hover-card-2 {
width: 190px;
height: 254px;
border-radius: 10px;
background: rgba(211, 211, 211, 0.199);
position: absolute;
transition: 0.3s ease-in-out;
cursor: pointer;
box-shadow: 0px 0px 30px -10px rgba(0, 0, 0, 0.3);
}

#c1 {
  background-color: #ffbe0b;
}

#c2 {
  background-color: #ff006e;
}

#c3 {
  background-color: #8338ec;
}

#c4 {
  background-color: #3a86ff;
}

.main-container:hover #c1 {
  transform: translateX(-100px) rotate(-40deg);
}

.main-container:hover #c2 {
  transform: translateX(-50px) rotate(-30deg);
}

.main-container:hover #c3 {
  transform: translateX(0) rotate(-20deg);
}

.main-container:hover #c4 {
  transform: translateX(50px) rotate(-10deg);
}

#c1:hover {
  transform: translateX(-150px) rotate(0deg) !important;
}

#c2:hover {
  transform: translateX(-100px) rotate(0deg) !important;
}

#c3:hover {
  transform: translateX(-50px) rotate(0deg) !important;
}

#c4:hover {
  transform: translateX(50px) rotate(0deg) !important;
}

.main-container {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 50vmax;
}
  
 `;
  return (
    <div className="code-container">
      <SyntaxHighlighter language="HTML" style={atomOneDark}>
        {codeString}
      </SyntaxHighlighter>
    </div>
  );
};
