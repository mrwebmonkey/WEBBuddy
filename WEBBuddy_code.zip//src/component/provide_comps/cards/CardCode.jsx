import SyntaxHighlighter from "react-syntax-highlighter";
import { atomOneDark } from "react-syntax-highlighter/dist/esm/styles/hljs";

export default Component = () => {
  const codeString = `
  <!-- HTML Code -->

  <div class="container">
        <div class="card">
          <h2>Basic Card</h2>
          <p>This is a simple card with some text.</p>
        </div>

        <div class="card image-card">
          <img src="https://via.placeholder.com/150" alt="Placeholder Image" />
          <h2>Image Card</h2>
          <p>This card contains an image.</p>
        </div>

        <div class="card shadow-card">
          <h2>Shadow Card</h2>
          <p>This card has a nice shadow effect.</p>
        </div>

        <div class="card hover-card">
          <h2>Hover Card</h2>
          <p>Hover over this card to see the effect.</p>
        </div>
      </div>

  <!-- CSS Code -->

  .container {
    display: flex;
    flex-wrap: wrap;
    gap: 20px;
  }
  
  .card {
    height: 310px;
    width: 200px;
    font-size: 16px;
    background-color: white;
    border-radius: 8px;
    padding: 20px;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    transition: transform 0.3s ease, box-shadow 0.3s ease;
  }
  
  .card h2 {
    margin-top: 0;
  }
  
  .image-card img {
    width: 100%;
    border-radius: 8px 8px 0 0;
  }
  
  .shadow-card {
    transition: box-shadow 0.3s ease;
  }
  
  .shadow-card:hover {
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
  }
  
  .hover-card {
    background-color: #e7f3ff;
    border: 1px solid #2196f3;
    cursor: pointer;
  }
  
  .hover-card:hover {
    transform: scale(1.05);
    background-color: #2196f3;
    color: white;
  }
  
  
 `;
  return (
    <div className="code-container">
      <SyntaxHighlighter language="HTML" style={atomOneDark}>
        {codeString}
      </SyntaxHighlighter>
    </div>
  );
};
