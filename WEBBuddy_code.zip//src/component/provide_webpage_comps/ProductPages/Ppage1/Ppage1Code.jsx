import SyntaxHighlighter from "react-syntax-highlighter";
import { atomOneDark } from "react-syntax-highlighter/dist/esm/styles/hljs";

export default Page1Code = () => {
  const codeString = `
  <!-- HTML Code -->

  <!-- Navbar -->
  <header class="header">
    <nav class="navbar">
      <div class="logo">Brand<span>Store</span></div>
      <ul class="nav-links">
        <li><a href="#features">Features</a></li>
        <li><a href="#pricing">Pricing</a></li>
        <li><a href="#reviews">Reviews</a></li>
      </ul>
      <button class="cta-button">Sign Up</button>
    </nav>
  </header>

  <!-- Product Section -->
  <section class="product">
    <div class="product-image">
      <img src="product.jpg" alt="Product Image">
    </div>
    <div class="product-details">
      <h1>Smart Gadget Pro</h1>
      <p>
        Experience cutting-edge technology with the Smart Gadget Pro. Perfect for staying connected, tracking your fitness, and making everyday tasks easier.
      </p>
      <h3>Key Features:</h3>
      <ul>
        <li>High-resolution touch display</li>
        <li>24/7 heart rate and fitness tracking</li>
        <li>Waterproof and lightweight design</li>
        <li>Seamless integration with all devices</li>
      </ul>
      <h2 class="price">$249.99</h2>
      <button class="buy-button">Buy Now</button>
      <button class="learn-button">Learn More</button>
    </div>
  </section>

  <!-- Reviews Section -->
  <section id="reviews" class="reviews">
    <h2>What Our Customers Say</h2>
    <div class="review-card">
      <p>
        "The Smart Gadget Pro has completely transformed my daily routine. It's a must-have!"
      </p>
      <h4>- Alex J.</h4>
    </div>
    <div class="review-card">
      <p>
        "Amazing features and sleek design. Highly recommend this product!"
      </p>
      <h4>- Sarah K.</h4>
    </div>
  </section>

  <!-- Footer -->
  <footer class="footer">
    <p>&copy; 2024 BrandStore. All Rights Reserved.</p>
    <ul class="footer-links">
      <li><a href="#features">Features</a></li>
      <li><a href="#pricing">Pricing</a></li>
      <li><a href="#reviews">Reviews</a></li>
    </ul>
  </footer>

  <!-- CSS Code -->

  /* General Reset */
  * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
  }
  
  body {
    font-family: 'Poppins', sans-serif;
    line-height: 1.6;
    color: #333;
    background: #f9f9f9;
  }
  
  /* Navbar */
  .navbar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 1rem 2rem;
    background: #333;
    color: #fff;
  }
  
  .logo {
    font-size: 1.8rem;
    font-weight: bold;
  }
  
  .logo span {
    color: #ff9800;
  }
  
  .nav-links {
    display: flex;
    list-style: none;
  }
  
  .nav-links li {
    margin: 0 1rem;
  }
  
  .nav-links a {
    text-decoration: none;
    color: #fff;
    font-weight: 600;
  }
  
  .cta-button {
    padding: 0.5rem 1.5rem;
    background: #ff9800;
    color: #fff;
    border: none;
    border-radius: 30px;
    font-weight: bold;
    cursor: pointer;
    transition: background-color 0.3s ease;
  }
  
  .cta-button:hover {
    background: #e68a00;
  }
  
  /* Product Section */
  .product {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 4rem 2rem;
    background: #fff;
  }
  
  .product-image img {
    width: 100%;
    max-width: 400px;
    border-radius: 10px;
  }
  
  .product-details {
    max-width: 500px;
  }
  
  .product-details h1 {
    font-size: 2.5rem;
    margin-bottom: 1rem;
  }
  
  .product-details p {
    font-size: 1.2rem;
    margin-bottom: 1.5rem;
  }
  
  .product-details ul {
    list-style: disc;
    margin-left: 1.5rem;
    margin-bottom: 1.5rem;
  }
  
  .price {
    font-size: 2rem;
    color: #ff9800;
    margin-bottom: 1.5rem;
  }
  
  .buy-button, .learn-button {
    padding: 0.8rem 2rem;
    border: none;
    border-radius: 30px;
    font-weight: bold;
    cursor: pointer;
    margin-right: 1rem;
    transition: transform 0.3s ease;
  }
  
  .buy-button {
    background: #ff9800;
    color: #fff;
  }
  
  .buy-button:hover {
    transform: scale(1.05);
    background: #e68a00;
  }
  
  .learn-button {
    background: #fff;
    color: #ff9800;
    border: 2px solid #ff9800;
  }
  
  .learn-button:hover {
    transform: scale(1.05);
    background: #ff9800;
    color: #fff;
  }
  
  /* Reviews Section */
  .reviews {
    padding: 3rem 2rem;
    text-align: center;
    background: #f9f9f9;
  }
  
  .reviews h2 {
    font-size: 2.5rem;
    margin-bottom: 2rem;
  }
  
  .review-card {
    background: #fff;
    margin: 1rem auto;
    padding: 1.5rem;
    max-width: 500px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    border-radius: 10px;
  }
  
  .review-card p {
    font-size: 1.2rem;
    margin-bottom: 1rem;
  }
  
  .review-card h4 {
    font-weight: bold;
  }
  
  /* Footer */
  .footer {
    padding: 2rem;
    background: #333;
    color: #fff;
    text-align: center;
  }
  
  .footer-links {
    list-style: none;
    margin-top: 1rem;
    display: flex;
    justify-content: center;
    gap: 1rem;
  }
  
  .footer-links a {
    color: #ff9800;
    text-decoration: none;
    font-weight: 600;
  }
  
      `;
  return (
    <SyntaxHighlighter language="HTML" style={atomOneDark}>
      {codeString}
    </SyntaxHighlighter>
  );
};
