import React from "react";

export default function Slider() {
  return (
    <div className="slider-container">
      <div className="slider">
        <div className=" black slides custom-font">Get Free Componets !</div>
        <div className=" white slides custom-font">$FREE</div>
        <div className=" black slides custom-font">Get Free Componets !</div>
        <div className=" white slides custom-font">$FREE</div>
        <div className=" black slides custom-font">Get Free Componets !</div>
        <div className=" white slides custom-font">$FREE</div>
        <div className=" black slides custom-font">Get Free Componets !</div>
      </div>
    </div>
  );
}
