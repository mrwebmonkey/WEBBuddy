import React from "react";

import Table from "../provide_comps/table/Table";
import TableCode from "../provide_comps/table/TableCode";

export default function Comp2() {
  return (
    <div>
      <div className="info-of-component">
        <p>
          Description: Tables display structured data in rows and columns for
          easy comparison. Usage: Data grids, financial reports, or analytics
          dashboards. Features: Sortable columns, pagination, filters, and
          responsive designs.
        </p>
      </div>
      <div className="preview-box">
        <div className="preview-box-head">
          <p>Preview</p>
        </div>
        <div className="preview">
          <Table />
        </div>
      </div>
      <div className="code-box">
        <div className="code-container-head">
          <p>Code</p>
        </div>
        <div className="code">
          <TableCode />
        </div>
      </div>
    </div>
  );
}
