import { Link } from "react-router-dom";
import ApageCode1 from "../../component/provide_webpage_comps/AboutPages/ApageCode1";

export default function AboutPageContainer() {
  return (
    <div className="login-page-con-center">
      <div className="page-center">
        <Link to="/Aboutpage1">
          <div className="page-container">
            <img
              src="http://127.0.0.1:5500/media/aboutpage-1.png"
              alt="login-page"
              height="520"
              width="900"
            />
          </div>
        </Link>
        <div className="code-container-2">
          <ApageCode1 />
        </div>
      </div>
    </div>
  );
}
