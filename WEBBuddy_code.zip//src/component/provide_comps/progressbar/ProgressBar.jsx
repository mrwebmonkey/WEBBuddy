export default function ProgressBar() {
  const style1 = {
    width: "50%",
    backgroundColor: "#e0e0e0",
    borderRadius: "5px",
    overflow: "hidden",
  };

  const style2 = {
    width: "60%",
    backgroundColor: "#000",
    height: "20px",
    transition: "width 0.3s",
  };

  return (
    <div style={style1}>
      <div style={style2}></div>
    </div>
  );
}
