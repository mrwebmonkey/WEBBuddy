import SyntaxHighlighter from "react-syntax-highlighter";
import { atomOneDark } from "react-syntax-highlighter/dist/esm/styles/hljs";

export default Component = () => {
  const codeString = `
  <!-- HTML Code -->

  <div class="music-menu">
  <h1>Music Library</h1>
  <ul class="song-list">
    <li class="song-item">
      <img
        src="https://via.placeholder.com/100"
        alt="Album Art"
        class="album-art"
      />
      <div class="song-info">
        <h2 class="song-title">Song Title 1</h2>
        <p class="artist-name">Artist 1</p>
      </div>
    </li>
    <li class="song-item">
      <img
        src="https://via.placeholder.com/100"
        alt="Album Art"
        class="album-art"
      />
      <div class="song-info">
        <h2 class="song-title">Song Title 2</h2>
        <p class="artist-name">Artist 2</p>
      </div>
    </li>
    <li class="song-item">
      <img
        src="https://via.placeholder.com/100"
        alt="Album Art"
        class="album-art"
      />
      <div class="song-info">
        <h2 class="song-title">Song Title 3</h2>
        <p class="artist-name">Artist 3</p>
      </div>
    </li>
    <li class="song-item">
      <img
        src="https://via.placeholder.com/100"
        alt="Album Art"
        class="album-art"
      />
      <div class="song-info">
        <h2 class="song-title">Song Title 4</h2>
        <p class="artist-name">Artist 4</p>
      </div>
    </li>
  </ul>
</div>
  
<!-- CSS Code -->

  .music-menu {
    width: 300px;
    padding: 20px;
    background-color: #1e1e1e;
    border-radius: 10px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.5);
  }
  
  .music-menu h1 {
    font-size: 24px;
    margin-bottom: 20px;
    text-align: center;
    color: #1db954;
  }
  
  .song-list {
    list-style: none;
  }
  
  .song-item {
    display: flex;
    align-items: center;
    padding: 10px;
    border-radius: 5px;
    transition: background 0.3s ease;
  }
  
  .song-item:hover {
    background-color: rgba(255, 255, 255, 0.1);
  }
  
  .album-art {
    width: 60px;
    height: 60px;
    border-radius: 5px;
    margin-right: 15px;
  }
  
  .song-info {
    display: flex;
    flex-direction: column;
  }
  
  .song-title {
    font-size: 18px;
    font-weight: bold;
  }
  
  .artist-name {
    font-size: 14px;
    color: #b3b3b3;
  }
  
      `;
  return (
    <div className="code-container">
      <SyntaxHighlighter language="HTML" style={atomOneDark}>
        {codeString}
      </SyntaxHighlighter>
    </div>
  );
};
