import React from "react";
import "./LPpage2.css";

const CreativeLandingPage = () => {
  return (
    <div>
      {/* Navbar */}
      <header className="header">
        <nav className="lp-2-navbar">
          <div className="logo">
            Creative<span>Space</span>
          </div>
          <ul className="nav-links">
            <li>
              <a href="#services">Services</a>
            </li>
            <li>
              <a href="#portfolio">Portfolio</a>
            </li>
            <li>
              <a href="#contact">Contact</a>
            </li>
          </ul>
          <button className="cta-button">Get Started</button>
        </nav>
      </header>

      {/* Hero Section */}
      <section className="hero">
        <div className="hero-content">
          <h1>
            Unleashing <span>Creativity</span> in Every Pixel
          </h1>
          <p>
            Transform your ideas into visually stunning designs with our
            innovative approach to creativity.
          </p>
          <button className="cta-button">Learn More</button>
        </div>
        <div className="hero-image">
          <img src="hero-image.jpg" alt="Creative Workspace" />
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="services">
        <h2>What I Offer</h2>
        <div className="services-container">
          <div className="service">
            <h3>UI/UX Design</h3>
            <p>
              Crafting seamless user experiences with clean and intuitive
              interfaces.
            </p>
          </div>
          <div className="service">
            <h3>Graphic Design</h3>
            <p>Bringing ideas to life with vibrant, eye-catching visuals.</p>
          </div>
          <div className="service">
            <h3>Branding</h3>
            <p>Helping businesses build strong, memorable brands.</p>
          </div>
        </div>
      </section>

      {/* Portfolio Section */}
      <section id="portfolio" className="portfolio">
        <h2>My Work</h2>
        <div className="portfolio-grid">
          <div className="portfolio-item">
            <img src="portfolio1.jpg" alt="Project 1" />
            <h3>Project Name 1</h3>
          </div>
          <div className="portfolio-item">
            <img src="portfolio2.jpg" alt="Project 2" />
            <h3>Project Name 2</h3>
          </div>
          <div className="portfolio-item">
            <img src="portfolio3.jpg" alt="Project 3" />
            <h3>Project Name 3</h3>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="footer">
        <div className="footer-content">
          <p>&copy; 2024 CreativeSpace. All Rights Reserved.</p>
          <ul className="footer-links">
            <li>
              <a href="#services">Services</a>
            </li>
            <li>
              <a href="#portfolio">Portfolio</a>
            </li>
            <li>
              <a href="#contact">Contact</a>
            </li>
          </ul>
        </div>
      </footer>
    </div>
  );
};

export default CreativeLandingPage;
